# jira_client.py
import httpx
import logging
import asyncio
import os
from datetime import datetime
from typing import List, Dict, Optional, Any

logger = logging.getLogger(__name__)

class JiraAuthError(Exception):
    """Исключение при ошибке аутентификации в Jira (401)"""
    pass

class JiraClient:
    def __init__(self, base_url: str = None, username: str = None, token: str = None):
        from .config import JIRA_BASE_URL
        
        self.base_url = (base_url or JIRA_BASE_URL).rstrip('/')
        self.username = username
        self.token = token
        
        self.headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.token}" if self.token else "",
            "Content-Type": "application/json"
        }
        
        # TLS verify options:
        #  - JIRA_TLS_VERIFY=true|false (default: true)
        #  - JIRA_CA_BUNDLE=/path/to/ca.pem (optional)
        tls_verify = os.getenv("JIRA_TLS_VERIFY", "true").lower() in ("1", "true", "yes", "on")
        ca_bundle = os.getenv("JIRA_CA_BUNDLE")

        verify_value = True
        if not tls_verify:
            verify_value = False
        elif ca_bundle:
            verify_value = ca_bundle

        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self.headers,
            verify=verify_value,
            timeout=30.0,
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=20)
        )
        
        logger.debug(f"Async JiraClient created for {username}")
    
    async def close(self):
        await self.client.aclose()
        logger.debug(f"Async JiraClient closed for {self.username}")
    
    async def _make_request(self, endpoint: str, method: str = "GET", params: Dict = None, 
                     data: Dict = None, timeout: int = 30) -> httpx.Response:
        url = endpoint
        
        max_retries = 5
        base_delay = 1
        
        for attempt in range(max_retries):
            try:
                logger.debug(f"Making {method} request to: {self.base_url}{url} (attempt {attempt + 1}/{max_retries})")
                
                response = await self.client.request(
                    method=method,
                    url=url,
                    params=params,
                    json=data,
                    timeout=timeout
                )
                
                logger.debug(f"Response status: {response.status_code}")
                
                if response.status_code == 429:
                    retry_after = int(response.headers.get('Retry-After', 60))
                    logger.warning(f"Rate limited. Waiting {retry_after} seconds...")
                    await asyncio.sleep(retry_after)
                    continue
                
                if response.status_code == 401:
                    logger.error(f"❌ Jira authentication failed (401) for user {self.username}")
                    raise JiraAuthError(f"Authentication failed: {response.status_code}")
                
                if 500 <= response.status_code < 600:
                    if attempt < max_retries - 1:
                        delay = base_delay * (2 ** attempt) + (0.1 * attempt)
                        logger.warning(f"Server error {response.status_code}. Retrying in {delay:.2f}s...")
                        await asyncio.sleep(delay)
                        continue
                    else:
                        logger.error(f"Max retries exceeded for server error {response.status_code}")
                        return response
                
                return response
                
            except httpx.ConnectError as e:
                logger.warning(f"Connection error (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt) + (0.1 * attempt)
                    logger.info(f"Waiting {delay:.2f} seconds before retry...")
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"Max retries exceeded for {url}")
                    raise
                    
            except httpx.TimeoutException as e:
                logger.warning(f"Timeout error (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt) + (0.1 * attempt)
                    await asyncio.sleep(delay)
                else:
                    raise
                    
            except Exception as e:
                logger.error(f"Request failed: {e}")
                raise
        
        raise Exception(f"Failed after {max_retries} attempts")
    
    async def test_connection(self) -> bool:
        temp_client = None
        try:
            temp_client = JiraClient(
                base_url=self.base_url,
                username=self.username,
                token=self.token
            )
            
            response = await temp_client._make_request("/rest/api/2/myself", method="GET")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Jira connection successful for user: {data.get('displayName', 'Unknown')}")
                return True
            else:
                logger.error(f"❌ Jira connection failed: {response.status_code} - {response.text[:200]}")
                return False
        except JiraAuthError:
            logger.error("❌ Jira authentication failed during test")
            return False
        except Exception as e:
            logger.error(f"❌ Jira connection error: {e}")
            return False
        finally:
            if temp_client:
                await temp_client.close()
    
    async def search(self, jql: str, max_results: int = 50) -> List[Dict[str, Any]]:
        try:
            params = {
                "jql": jql,
                "maxResults": max_results,
                "fields": "id,key,summary,assignee,status,priority,updated,issuelinks,comment,reporter"
            }
            
            response = await self._make_request("/rest/api/2/search", params=params)
            
            if response.status_code == 200:
                data = response.json()
                issues = data.get("issues", [])
                logger.info(f"✅ Found {len(issues)} issues for JQL: {jql[:50]}...")
                return issues
            else:
                logger.error(f"❌ Search failed: {response.status_code} - {response.text[:200]}")
                return []
                
        except JiraAuthError:
            raise
        except Exception as e:
            logger.error(f"❌ Search error: {e}")
            return []
    
    async def search_with_details(self, jql: str, max_results: int = 50) -> List[Dict[str, Any]]:
        try:
            fields = (
                "id,key,summary,assignee,status,priority,updated,issuelinks,"
                "comment,reporter,description,creator,labels,duedate,components,"
                "customfield_24525"
            )
            params = {
                "jql": jql,
                "maxResults": max_results,
                "fields": fields
            }
    
            response = await self._make_request("/rest/api/2/search", params=params)
    
            if response.status_code == 200:
                data = response.json()
                issues = data.get("issues", [])
                logger.info(f"✅ Found {len(issues)} issues with details for JQL: {jql[:50]}...")
                return issues
            else:
                logger.error(f"❌ Search with details failed: {response.status_code} - {response.text[:200]}")
                return []
    
        except JiraAuthError:
            raise
        except Exception as e:
            logger.error(f"❌ Search with details error: {e}")
            return []
    
    async def get_issue(self, issue_key: str) -> Optional[Dict[str, Any]]:
        try:
            params = {
                "fields": "id,key,summary,assignee,status,priority,updated,issuelinks,comment,reporter,description,creator"
            }
            
            response = await self._make_request(f"/rest/api/2/issue/{issue_key}", params=params)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"❌ Get issue failed: {response.status_code} - {response.text[:200]}")
                return None
                
        except JiraAuthError:
            raise
        except Exception as e:
            logger.error(f"❌ Get issue error: {e}")
            return None
    
    async def get_issue_with_comments(self, issue_key: str) -> Optional[Dict[str, Any]]:
        try:
            params = {
                "fields": "id,key,summary,assignee,status,priority,updated,issuelinks,comment,reporter,description,creator",
                "expand": "comment"
            }
            
            response = await self._make_request(f"/rest/api/2/issue/{issue_key}", params=params)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"❌ Get issue with comments failed: {response.status_code} - {response.text[:200]}")
                return None
                
        except JiraAuthError:
            raise
        except Exception as e:
            logger.error(f"❌ Get issue with comments error: {e}")
            return None
    
    async def get_comments(self, issue_key: str) -> List[Dict[str, Any]]:
        try:
            response = await self._make_request(f"/rest/api/2/issue/{issue_key}/comment")
            
            if response.status_code == 200:
                data = response.json()
                return data.get("comments", [])
            else:
                logger.error(f"❌ Get comments failed: {response.status_code} - {response.text[:200]}")
                return []
                
        except JiraAuthError:
            raise
        except Exception as e:
            logger.error(f"❌ Get comments error: {e}")
            return []
    
    def is_resolved_status(self, status_name: str) -> bool:
        if not status_name:
            return False
            
        resolved_statuses = [
            'closed', 'закрыт', 'закрыто', 'done', 'выполнено', 'resolved',
            'решена', 'готово', 'готов', 'отклонено', 'rejected', 'cancelled',
            'отменено', 'отменен', 'решен', 'завершено', 'завершен','исправлен','ответ получен','доступ выдан'
        ]
        
        status_lower = status_name.lower().strip()
        return any(resolved_status in status_lower for resolved_status in resolved_statuses)
    
    async def search_mentions_batch(self, username: str, last_check_time: str = None, 
                             batch_size: int = 10, exclude_resolved: bool = True) -> List[Dict]:
        try:
            jql = f'text ~ "@{username}"'
            
            if last_check_time:
                try:
                    clean_time = last_check_time.replace('Z', '+00:00').replace('T', ' ')
                    
                    formats_to_try = [
                        "%Y-%m-%d %H:%M:%S.%f",
                        "%Y-%m-%d %H:%M:%S",
                        "%Y-%m-%d %H:%M",
                        "%Y-%m-%d"
                    ]
                    
                    parsed_dt = None
                    for fmt in formats_to_try:
                        try:
                            parsed_dt = datetime.strptime(clean_time.split('+')[0].strip(), fmt)
                            break
                        except ValueError:
                            continue
                    
                    if parsed_dt:
                        jira_time_format = parsed_dt.strftime("%Y-%m-%d %H:%M")
                        jql += f' AND updated >= "{jira_time_format}"'
                        logger.info(f"📅 Using Jira time format: {jira_time_format} (from {last_check_time})")
                    else:
                        logger.warning(f"⚠️ Could not parse time: {last_check_time}, skipping time filter")
                        
                except Exception as time_error:
                    logger.error(f"❌ Error parsing time {last_check_time}: {time_error}")
                    pass
            
            if exclude_resolved:
                jql += f' AND statusCategory != Done'
            
            logger.info(f"🔍 Searching mentions for @{username} with batch size {batch_size}")
            logger.info(f"📝 JQL: {jql}")
            
            all_issues = []
            start_at = 0
            total_issues = 0
            
            while True:
                params = {
                    "jql": jql,
                    "maxResults": batch_size,
                    "startAt": start_at,
                    "fields": "id,key,summary,assignee,status,priority,updated,comment,reporter,creator,description",
                    "expand": "comment"
                }
                
                response = await self._make_request("/rest/api/2/search", params=params)
                
                if response.status_code != 200:
                    logger.error(f"Search mentions failed: {response.status_code} - {response.text[:200]}")
                    break
                
                data = response.json()
                issues = data.get("issues", [])
                total_issues = data.get("total", 0)
                
                if exclude_resolved:
                    filtered_issues = []
                    for issue in issues:
                        status_name = issue.get("fields", {}).get("status", {}).get("name", "")
                        if not self.is_resolved_status(status_name):
                            filtered_issues.append(issue)
                        else:
                            logger.debug(f"Filtered out resolved issue: {issue.get('key')} with status: {status_name}")
                    issues = filtered_issues
                
                all_issues.extend(issues)
                
                logger.info(f"Batch {start_at//batch_size + 1}: loaded {len(issues)} active issues, total {len(all_issues)}/{total_issues}")
                
                if start_at + batch_size >= total_issues or len(issues) == 0:
                    break
                    
                start_at += batch_size
                
                await asyncio.sleep(0.5)
            
            logger.info(f"✅ Found {len(all_issues)} active issues mentioning @{username} (excluding resolved)")
            return all_issues
            
        except JiraAuthError:
            raise
        except Exception as e:
            logger.error(f"Search mentions error: {e}")
            return []