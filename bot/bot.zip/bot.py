# bot.py
import asyncio
import logging
import html
import inspect
import os
import re
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime, timedelta
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    InlineQueryResultArticle, InputTextMessageContent,
    ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
)
from telegram.constants import ParseMode
from telegram.error import TimedOut, NetworkError, RetryAfter, BadRequest, TelegramError

from .fun import get_random_meme, get_random_horoscope, get_random_fact, close_http_client, ROLE_PREFIX, ZODIAC_MAP

from telegram.ext import (
    Application, CommandHandler, ContextTypes,
    ConversationHandler, MessageHandler, filters,
    CallbackQueryHandler, InlineQueryHandler
)

from .config import BOT_TOKEN, DEFAULT_CHECK_INTERVAL, ADMIN_USER_IDS, REMINDER_INTERVAL_MINUTES, MENTIONS_ENABLED, MENTIONS_CHECK_INTERVAL
from .db import db
from .jira_manager import jira_manager
from .watcher import smart_watcher
from .mentions import mentions_tracker
from .utils import get_msk_time, format_time_until_morning, should_send_reminder_check, get_msk_time_obj

# Подключаем фичи
from .digest import generate_user_digest, daily_digest_scheduler
from .jira_client import JiraAuthError

logger = logging.getLogger(__name__)

# Безопасное получение URL для WebApp
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://google.com")

# Состояния для ConversationHandler
SETUP_JIRA_USER, SETUP_JIRA_TOKEN, ADD_FILTER_NAME, ADD_FILTER_JQL = range(4)

# Глобальные переменные
bot_app = None
watcher_task = None
digest_task = None
user_muted = {}  # user_id -> muted status


# ------------------- UI / FSM (упрощённая навигация через inline) -------------------
# callback_data формат: ui:<scope>:<action>[:arg1[:arg2...]]
UI_PREFIX = "ui:"

def ui_cb(*parts: str) -> str:
    safe = []
    for p in parts:
        p = (p or "").replace(":", "_")
        safe.append(p)
    return UI_PREFIX + ":".join(safe)

# ------------------- Функция получения активных блокеров (вынесена из blockers_cmd) -------------------
async def collect_active_blockers_now(
    user_id_db: int,
    client,
    filters_list: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], bool]:
    """Собрать активные блокировки *сейчас* в Jira для задач, попавших в фильтры пользователя.

    Возвращает: (list_of_blockers, is_truncated)

    list_of_blockers: элементы вида
      {
        blocker_key, blocked_issue, filter_name, status, assignee, summary, updated, url
      }

    Ограничения на объём регулируются env:
      BLOCKERS_MAX_ISSUES_PER_FILTER (default 50)
      BLOCKERS_MAX_TOTAL_ISSUES (default 200)
    """
    all_blockers: List[Dict[str, Any]] = []
    seen = set()  # (filter_name, blocked_issue, blocker_key)

    max_issues_per_filter = int(os.getenv("BLOCKERS_MAX_ISSUES_PER_FILTER", "50"))
    max_total_issues = int(os.getenv("BLOCKERS_MAX_TOTAL_ISSUES", "200"))

    total_issues_processed = 0
    truncated = False

    for f in filters_list:
        if total_issues_processed >= max_total_issues:
            truncated = True
            break

        filter_name = f.get("filter_name") or ""
        jql = (f.get("jql") or "").strip()
        if not jql:
            continue

        try:
            issues = await client.search_with_details(jql, max_results=max_issues_per_filter)
        except JiraAuthError:
            raise
        except Exception as e:
            logger.error(f"❌ collect_active_blockers_now: search failed for filter {filter_name}: {e}")
            continue

        for issue in issues:
            if total_issues_processed >= max_total_issues:
                truncated = True
                break

            total_issues_processed += 1

            try:
                blockers = await smart_watcher.analyze_blockers(user_id_db, filter_name, issue, client)
            except Exception as e:
                logger.error(f"❌ collect_active_blockers_now: analyze_blockers failed: {e}")
                continue

            for b in blockers or []:
                if b and not b.get("is_resolved", True):
                    key = b.get("key") or ""
                    uniq = (filter_name, issue.get("key"), key)
                    if uniq in seen:
                        continue
                    seen.add(uniq)

                    all_blockers.append({
                        "blocker_key": key,
                        "blocked_issue": issue.get("key"),
                        "filter_name": filter_name,
                        "status": b.get("status", "Неизвестно"),
                        "assignee": b.get("assignee", "Не назначен"),
                        "summary": b.get("summary", "Без названия"),
                        "updated": b.get("updated"),
                        "url": b.get("url"),
                    })

    return all_blockers, truncated

# ------------------- Рендер экранов -------------------

async def render_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int = None, chat_id: int = None):
    """Главный экран-дашборд"""
    if user_id is None:
        user_data = await get_user_data(update)
        user_id = user_data["user_id"]
        chat_id = user_id  # для отправки сообщения

    stats = await db.get_dashboard_stats(user_id)
    pending = stats["pending_notifications"]
    unread_mentions = stats["unread_mentions"]

    # Получаем активные блокировки через Jira (если есть клиент)
    active_blockers = 0
    client = jira_manager.get_client(user_id)
    if client:
        filters = await db.get_user_filters(user_id, active_only=True)
        if filters:
            try:
                blockers_list, truncated = await collect_active_blockers_now(user_id, client, filters)
                active_blockers = len(blockers_list)
            except Exception as e:
                logger.error(f"Error getting blockers for dashboard: {e}")

    user_info = await db.get_user(user_id)
    first_name = user_info.get("first_name", "Пользователь")

    text = (
        f"👋 Привет, {html.escape(first_name)}!\n\n"
        f"📊 Сегодня:\n"
        f"• 🔔 {pending} активных уведомлений\n"
        f"• 💬 {unread_mentions} новых упоминаний\n"
        f"• 🚧 {active_blockers} блокирующих задач\n\n"
        "Выбери действие:"
    )

    keyboard = [
        [InlineKeyboardButton(f"📥 Уведомления ({pending})", callback_data=ui_cb("dashboard", "notifications"))],
        [InlineKeyboardButton(f"💬 Упоминания ({unread_mentions})", callback_data=ui_cb("dashboard", "mentions"))],
        [InlineKeyboardButton("📁 Мои фильтры", callback_data=ui_cb("dashboard", "filters"))],
        [InlineKeyboardButton("➕ Добавить фильтр", callback_data=ui_cb("cmd", "addfilter"))],
        [InlineKeyboardButton("⚙️ Настройки", callback_data=ui_cb("dashboard", "settings"))],
        [InlineKeyboardButton("🎭 Fun-режим", callback_data=ui_cb("fun", "menu"))],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Отправляем/редактируем сообщение
    ui_state = context.user_data.get("ui_state", {})
    msg_id = ui_state.get("message_id")
    new_msg_id = await send_message_safe(user_id, text, reply_markup=reply_markup, message_id=msg_id)
    context.user_data["ui_state"] = {"screen": "dashboard", "message_id": new_msg_id}


async def render_notifications_screen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    pending = await db.get_pending_notifications_grouped(user_id)

    if not pending:
        text = "📭 У вас нет неподтверждённых уведомлений."
        keyboard = [[InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))]]
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        return

    text = "📥 Неподтверждённые уведомления:\n\n"
    keyboard = []
    for item in pending:
        issue_key = item["issue_key"]
        filter_name = item["filter_name"]
        count = item["count"]
        # Используем filter_id и issue_key в callback
        filter_id = await db.get_filter_id_by_name(user_id, filter_name)
        if filter_id is None:
            continue
        callback_data = f"notif:open:{filter_id}:{issue_key}"
        keyboard.append([InlineKeyboardButton(f"🔴 {issue_key} ({count})", callback_data=callback_data)])

    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))])
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))


async def render_notification_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, filter_id: int, issue_key: str):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    filter_name = await db.get_filter_name_by_id(user_id, filter_id)
    if not filter_name:
        await query.answer("Фильтр не найден")
        return

    notifs = await db.get_notifications_by_issue(user_id, issue_key)
    relevant = [n for n in notifs if n["filter_name"] == filter_name and not n.get("user_reaction")]
    if not relevant:
        await query.answer("Нет неподтверждённых уведомлений для этой задачи")
        return

    last = relevant[0]
    details = last.get("details", {})
    summary = details.get("summary", "Без названия")
    status = details.get("status", "Неизвестно")
    priority = details.get("priority", "Не указан")
    changes = details.get("changes", {})
    changes_desc = smart_watcher.get_change_description(changes)[1]

    text = (
        f"🔴 <b>{issue_key}</b>\n"
        f"Фильтр: {filter_name}\n"
        f"Сводка: {html.escape(summary)}\n"
        f"Статус: {status}\n"
        f"Приоритет: {priority}\n"
        f"Изменения: {changes_desc}\n\n"
        f"Количество неподтверждённых уведомлений: {len(relevant)}"
    )

    notif_id = last["id"]
    keyboard = [
        [InlineKeyboardButton("✅ Принял", callback_data=f"notif:ack:{notif_id}")],
        [InlineKeyboardButton("🔕 Не напоминать 24ч", callback_data=f"notif:mute:{filter_id}:{issue_key}")],
        [InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("dashboard", "notifications"))],
    ]
    client = jira_manager.get_client(user_id)
    if client:
        keyboard.insert(0, [InlineKeyboardButton("🔗 Открыть в Jira", url=f"{client.base_url}/browse/{issue_key}")])

    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.HTML)


async def render_mentions_screen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    mention_data = await mentions_tracker.get_mention_notification_data(user_id)
    if not mention_data:
        text = "💬 У вас нет новых упоминаний."
        keyboard = [[InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))]]
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        return

    text = "💬 Ваши упоминания:\n\n"
    keyboard = []
    for item in mention_data:
        issue_key = item["issue_key"]
        count = item["total_mentions"]
        mentioners = item.get("mentioners", [])
        mentioners_str = ", ".join(mentioners[:2])
        if len(mentioners) > 2:
            mentioners_str += f" и ещё {len(mentioners)-2}"
        text += f"📌 {issue_key} — {count} упоминаний\n👤 {mentioners_str}\n\n"
        keyboard.append([InlineKeyboardButton(f"👀 {issue_key}", callback_data=f"mention:open:{issue_key}")])

    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))])
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))


async def render_mention_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, issue_key: str):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    # Получаем все упоминания по задаче (непрочитанные)
    conn = await db._get_conn()
    cursor = await conn.execute(
        "SELECT mentioned_by, mention_text, created_at FROM user_mentions WHERE user_id = ? AND issue_key = ? AND notification_sent = 0 ORDER BY created_at DESC",
        (user_id, issue_key)
    )
    rows = await cursor.fetchall()
    if not rows:
        await query.answer("Нет непрочитанных упоминаний")
        return

    text = f"💬 <b>{issue_key}</b>\n\n"
    for row in rows:
        author = row["mentioned_by"] or "Неизвестно"
        mention_text = row["mention_text"] or ""
        created = row["created_at"][:16] if row["created_at"] else ""
        text += f"👤 {html.escape(author)} ({created}):\n{html.escape(mention_text[:200])}\n\n"

    keyboard = [
        [InlineKeyboardButton("✅ Пометить прочитанным", callback_data=f"mention:read:{issue_key}")],
        [InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("dashboard", "mentions"))],
    ]
    client = jira_manager.get_client(user_id)
    if client:
        keyboard.insert(0, [InlineKeyboardButton("🔗 Открыть в Jira", url=f"{client.base_url}/browse/{issue_key}")])

    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.HTML)


async def render_filters_screen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    filters = await db.get_user_filters(user_id, active_only=False)
    if not filters:
        text = "📁 У вас нет фильтров. Добавьте первый."
        keyboard = [
            [InlineKeyboardButton("➕ Добавить фильтр", callback_data=ui_cb("cmd", "addfilter"))],
            [InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))],
        ]
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
        return

    text = "📁 Мои фильтры:\n\n"
    keyboard = []
    for f in filters:
        status = "🟢" if f["is_active"] else "🔴"
        filter_id = f["id"]
        filter_name = f["filter_name"]
        text += f"{status} <b>{html.escape(filter_name)}</b>\n"
        text += f"JQL: <code>{html.escape(f['jql'][:50])}...</code>\n"
        text += f"Интервал: {f['check_interval']} мин | Хранение: {f.get('retention_days', 30)} дн.\n\n"
        keyboard.append([InlineKeyboardButton(f"{status} {filter_name}", callback_data=f"filter:open:{filter_id}")])

    keyboard.append([InlineKeyboardButton("➕ Добавить фильтр", callback_data=ui_cb("cmd", "addfilter"))])
    keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))])
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.HTML)


async def render_filter_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, filter_id: int):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    filter_info = await db.get_filter_by_id(user_id, filter_id)  # добавим метод
    if not filter_info:
        await query.answer("Фильтр не найден")
        return

    filter_name = filter_info["filter_name"]
    jql = filter_info["jql"]
    is_active = filter_info["is_active"]
    interval = filter_info["check_interval"]
    retention = filter_info.get("retention_days", 30)

    status_text = "🟢 Активен" if is_active else "🔴 Неактивен"
    text = (
        f"📁 <b>{html.escape(filter_name)}</b>\n\n"
        f"JQL: <code>{html.escape(jql)}</code>\n\n"
        f"Статус: {status_text}\n"
        f"Интервал: {interval} мин\n"
        f"Хранение: {retention} дней\n\n"
        "Выберите действие:"
    )

    keyboard = [
        [InlineKeyboardButton("⏸ Вкл/Выкл", callback_data=f"filter:toggle:{filter_id}")],
        [InlineKeyboardButton("⏱ Изменить интервал", callback_data=f"filter:interval:{filter_id}")],
        [InlineKeyboardButton("♻️ Изменить хранение", callback_data=f"filter:retention:{filter_id}")],
        [InlineKeyboardButton("✏️ Изменить JQL", callback_data=f"filter:edit:{filter_id}")],
        [InlineKeyboardButton("🗑 Удалить", callback_data=f"filter:delete:{filter_id}")],
        [InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("dashboard", "filters"))],
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.HTML)


async def render_blockers_screen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    client = jira_manager.get_client(user_id)
    if not client:
        await query.edit_message_text("❌ Jira не настроена.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))]]))
        return

    filters = await db.get_user_filters(user_id, active_only=True)
    if not filters:
        await query.edit_message_text("❌ Нет активных фильтров.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))]]))
        return

    await query.edit_message_text("🔄 Собираю активные блокировки...")
    try:
        blockers, truncated = await collect_active_blockers_now(user_id, client, filters)
    except JiraAuthError:
        await handle_jira_auth_error(user_id)
        return

    if not blockers:
        text = "✅ Активных блокировок не найдено."
    else:
        text = "🚧 <b>Активные блокировки</b>\n\n"
        for b in blockers[:10]:
            blocker_key = html.escape(str(b.get('blocker_key', '')))
            blocked_issue = html.escape(str(b.get('blocked_issue', '')))
            status = html.escape(str(b.get('status', '')))
            assignee = html.escape(str(b.get('assignee', '')))
            filter_name = html.escape(str(b.get('filter_name', '')))
            text += f"• <b>{blocker_key}</b> → блокирует {blocked_issue}\n"
            text += f"  Статус: {status} | Исполнитель: {assignee}\n"
            text += f"  Фильтр: {filter_name}\n\n"
        if len(blockers) > 10:
            text += f"... и ещё {len(blockers)-10}\n"
        if truncated:
            text += "\n⚠️ Показаны не все из-за ограничений."

    keyboard = [[InlineKeyboardButton("🔄 Обновить", callback_data=ui_cb("dashboard", "blockers"))],
                [InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))]]
    try:
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.HTML)
    except BadRequest as e:
        if "message is not modified" in str(e).lower():
            logger.info("ℹ️ Blockers screen: message is not modified")
            return
        raise



async def render_settings_screen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id

    settings = await db.get_fun_settings(user_id)
    fun_mode = settings.get("fun_mode", "off")
    personality = settings.get("personality", "neutral")
    zodiac = settings.get("zodiac") or "не задан"
    whisper = "вкл" if settings.get("whisper_enabled", 1) else "выкл"

    text = (
        "⚙️ <b>Настройки</b>\n\n"
        f"🎭 Fun-режим: <b>{fun_mode}</b>\n"
        f"🧠 Роль бота: <b>{personality}</b>\n"
        f"🔕 Ночной шёпот: <b>{whisper}</b>\n"
        f"🔮 Знак зодиака: <b>{zodiac}</b>\n\n"
        "Выберите параметр для изменения:"
    )

    keyboard = [
        [InlineKeyboardButton("🎭 Fun-режим", callback_data="settings:funmode")],
        [InlineKeyboardButton("🧠 Роль бота", callback_data="settings:personality")],
        [InlineKeyboardButton("🔕 Ночной шёпот", callback_data="settings:whisper")],
        [InlineKeyboardButton("🔮 Знак зодиака", callback_data="settings:zodiac")],
        [InlineKeyboardButton("⬅️ Назад", callback_data=ui_cb("nav", "home"))],
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode=ParseMode.HTML)


# ------------------- Вспомогательные функции -------------------
def clean_text(text: str) -> str:
    if not text:
        return ""
    return html.escape(str(text))

async def get_user_data(update: Update) -> Dict[str, Any]:
    """Получить данные пользователя из базы (асинхронно)"""
    user = update.effective_user
    chat = update.effective_chat
    user_data = await db.get_or_create_user(
        user_id=user.id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name,
        chat_id=chat.id if chat else None
    )
    return user_data

async def send_message_safe(user_id: int, text: str, parse_mode: str = ParseMode.HTML,
                           reply_markup = None, message_id: Optional[int] = None) -> Optional[int]:
    """
    Безопасная отправка сообщения с обработкой ошибок
    Возвращает ID отправленного сообщения или None
    """
    if not bot_app:
        logger.error("❌ Bot app not initialized")
        return None

    async def _call_with_retry(fn, *args, **kwargs):
        """Единая обёртка для вызовов Telegram API.

        Частые проблемы в проде:
        - TimedOut / NetworkError из-за сетевых сбоев
        - RetryAfter при rate-limit

        Мы ретраим аккуратно, чтобы не ддосить Telegram.
        """
        max_attempts = int(os.getenv("TG_MAX_RETRY", "4"))
        base_delay = float(os.getenv("TG_RETRY_DELAY", "0.7"))
        last_err: Optional[Exception] = None

        for attempt in range(1, max_attempts + 1):
            try:
                return await fn(*args, **kwargs)
            except RetryAfter as e:
                last_err = e
                delay = max(1.0, float(getattr(e, "retry_after", 1.0)))
                logger.warning(f"⏳ Telegram rate-limit (RetryAfter {delay}s), attempt {attempt}/{max_attempts}")
                await asyncio.sleep(delay)
            except (TimedOut, NetworkError) as e:
                last_err = e
                delay = base_delay * attempt
                logger.warning(f"🌐 Telegram network/timeout error, attempt {attempt}/{max_attempts}: {e}")
                await asyncio.sleep(delay)
            except BadRequest as e:
                # Частый кейс при edit: Message is not modified / message to edit not found / can't parse entities
                msg = str(e)
                if "message is not modified" in msg.lower():
                    logger.info("ℹ️ Telegram edit skipped: message is not modified")
                    return None
                if "can't parse entities" in msg.lower() or "cant parse entities" in msg.lower():
                    logger.error(f"❌ Telegram parse error (entities). Text will be sent without parse_mode. Error: {e}")
                    # Попробуем один раз без parse_mode (HTML может ломаться из-за неэкранированных символов)
                    kwargs2 = dict(kwargs)
                    kwargs2.pop("parse_mode", None)
                    return await fn(*args, **kwargs2)
                raise
            except TelegramError as e:
                # Всё остальное — обычно не transient, но одну попытку можно сделать
                last_err = e
                if attempt >= max_attempts:
                    raise
                delay = base_delay * attempt
                logger.warning(f"⚠️ Telegram API error, attempt {attempt}/{max_attempts}: {e}")
                await asyncio.sleep(delay)

        raise last_err  # type: ignore

    try:
        user = await db.get_user(user_id)
        if not user or not user.get("chat_id"):
            logger.warning(f"User {user_id} not found or no chat_id")
            return None

        chat_id = user["chat_id"]
        safe_text = text

        if len(safe_text) > 4096:
            logger.warning(f"Text too long ({len(safe_text)} chars), truncating...")
            safe_text = safe_text[:4000] + "\n\n...[текст сокращен]"

        logger.debug(f"Sending message to user {user_id}, chat {chat_id}")

        if message_id:
            try:
                message = await _call_with_retry(
                    bot_app.bot.edit_message_text,
                    chat_id=chat_id,
                    message_id=message_id,
                    text=safe_text,
                    parse_mode=parse_mode,
                    reply_markup=reply_markup,
                    disable_web_page_preview=True
                )
                logger.debug(f"Message {message_id} edited successfully for user {user_id}")
                return message_id
            except Exception as edit_error:
                if "Message is not modified" in str(edit_error):
                    logger.debug(f"Message {message_id} not modified for user {user_id}")
                else:
                    logger.error(f"Failed to edit message {message_id} for user {user_id}: {edit_error}")
                message_id = None

        if not message_id:
            try:
                message = await _call_with_retry(
                    bot_app.bot.send_message,
                    chat_id=chat_id,
                    text=safe_text,
                    parse_mode=parse_mode,
                    reply_markup=reply_markup,
                    disable_web_page_preview=True
                )
                logger.debug(f"Message sent successfully to user {user_id}, message_id: {message.message_id}")
                return message.message_id
            except Exception as send_error:
                logger.error(f"Failed to send message to user {user_id}: {send_error}")
                return None

    except Exception as e:
        logger.error(f"❌ Critical error sending message to user {user_id}: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return None

# ------------------- Функция обработки ошибки 401 -------------------
async def handle_jira_auth_error(user_id: int, context_msg: str = ""):
    """Обрабатывает ошибку 401: уведомляет пользователя и админов (не чаще раза в час), удаляет клиент."""
    last_error = await db.get_last_auth_error_time(user_id)
    now = datetime.now()
    send_notification = False
    if last_error is None:
        send_notification = True
    else:
        try:
            last_time = datetime.fromisoformat(last_error)
            if (now - last_time) > timedelta(hours=1):
                send_notification = True
        except:
            send_notification = True  # на случай битого формата

    if send_notification:
        await db.update_last_auth_error_time(user_id, now.isoformat())
        # Пользователю
        await send_message_safe(
            user_id,
            "❌ Проблема с авторизацией в Jira. Возможно, истек срок действия токена.\n"
            "Пожалуйста, настройте подключение заново: /setup"
        )
        # Админам
        for admin_id in ADMIN_USER_IDS:
            await send_message_safe(
                admin_id,
                f"🚨 У пользователя {user_id} возникла ошибка авторизации в Jira (401)."
            )
    # Удаляем клиент (он всё равно нерабочий)
    await jira_manager.remove_client(user_id)

# ------------------- Общие функции -------------------
async def cancel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отмена любого диалога"""
    user_id = update.effective_user.id
    session_id = context.user_data.get("session_id")
    if session_id:
        await db.delete_session(session_id)
        if "session_id" in context.user_data:
            del context.user_data["session_id"]
    await send_message_safe(user_id, "❌ Операция отменена.")
    return ConversationHandler.END

# ------------------- Обработка реакций (старые callback'и) -------------------
async def handle_reaction_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка реакций на уведомления (старый формат)"""
    query = update.callback_query
    await query.answer()

    data = query.data
    user_id = query.from_user.id

    if data.startswith("ack_"):
        parts = data.split("_")
        if len(parts) >= 3:
            issue_key = parts[1]
            notification_hash = parts[2]

            await db.record_user_reaction(user_id, issue_key, notification_hash)

            # Геймификация: XP + стрик (если fun включен)
            settings = await _get_fun_settings(user_id)
            if _is_fun_enabled(settings):
                try:
                    prog = await db.apply_ack_gamification(user_id)
                    xp_gain = prog.get('xp_gain', 0)
                    if xp_gain:
                        await send_message_safe(user_id, f"🏆 +{xp_gain} XP за дисциплину! 🔥 streak {prog.get('streak', 0)}")
                except Exception:
                    pass

            await query.edit_message_reply_markup(reply_markup=None)
            await send_message_safe(user_id, "✅ Вы подтвердили получение уведомления. Я больше не буду напоминать об этой задаче.")
            logger.info(f"User {user_id} acknowledged notification for {issue_key}")

    elif data.startswith("mute_"):
        parts = data.split("_", 2)
        if len(parts) >= 3:
            issue_key = parts[1]
            filter_part = parts[2]

            filter_name = None

            # Новый формат: mute_{ISSUEKEY}_{FILTER_ID}
            if filter_part.isdigit():
                try:
                    filter_id = int(filter_part)
                    filter_name = await db.get_filter_name_by_id(user_id, filter_id)
                except Exception:
                    filter_name = None

            # Backward-compat / fallback: mute_{ISSUEKEY}_{FILTER_NAME}
            if not filter_name:
                filter_name_from_callback = filter_part

                import re
                filter_match = re.search(r'Фильтр: (.+)', query.message.text)
                filter_name = filter_name_from_callback
                if filter_match:
                    real_filter_name = filter_match.group(1).strip()
                    if real_filter_name != filter_name_from_callback:
                        logger.info(
                            f"🎯 Found real filter name in message: '{real_filter_name}' instead of callback '{filter_name_from_callback}'"
                        )
                        filter_name = real_filter_name

            success = await db.mute_task_notifications(user_id, issue_key, filter_name, hours=24)

            if success:
                conn = await db._get_conn()
                await conn.execute(
                    "UPDATE notifications SET user_reaction = 'muted_by_user' WHERE user_id = ? AND issue_key = ? AND filter_name = ? AND (user_reaction IS NULL OR user_reaction = '')",
                    (user_id, issue_key, filter_name)
                )
                await conn.commit()

                await conn.execute(
                    "DELETE FROM notifications WHERE user_id = ? AND issue_key = ? AND filter_name = ? AND is_reminder = 1",
                    (user_id, issue_key, filter_name)
                )
                await conn.commit()

                cursor = await conn.execute(
                    "SELECT filter_name FROM notifications WHERE user_id = ? AND issue_key = ? AND (user_reaction IS NULL OR user_reaction = '')",
                    (user_id, issue_key)
                )
                all_filters = [row[0] for row in await cursor.fetchall()]
                if all_filters:
                    logger.info(f"📋 All filters for issue {issue_key}: {all_filters}")
                    for f_name in all_filters:
                        if f_name != filter_name:
                            logger.info(f"🔄 Also muting for filter: {f_name}")
                            await db.mute_task_notifications(user_id, issue_key, f_name, hours=24)

                await query.edit_message_reply_markup(reply_markup=None)
                await send_message_safe(user_id, f"🔕 Уведомления для задачи {issue_key} отключены на 24 часа.")
                logger.info(f"User {user_id} muted notifications for {issue_key} (filter: {filter_name})")
            else:
                logger.error(f"❌ Failed to mute notifications for {issue_key}")

    elif data.startswith("mention_ack_"):
        issue_key = data.replace("mention_ack_", "")
        await db.mark_mentions_as_notified(user_id, issue_key)
        await query.edit_message_reply_markup(reply_markup=None)
        await send_message_safe(user_id, f"✅ Упоминания в задаче {issue_key} отмечены как прочитанные.")
        logger.info(f"User {user_id} acknowledged mentions for {issue_key}")

    elif data.startswith("editfilter_select_"):
        filter_name = data.replace("editfilter_select_", "")
        context.user_data["editing_filter"] = filter_name
        context.user_data["pending_cmd"] = "editfilter_jql"
        await query.edit_message_text(
            f"✏️ Редактирование фильтра <b>{filter_name}</b>\n"
            "Введите новый JQL запрос:",
            parse_mode=ParseMode.HTML
        )

    elif data == "noop":
        await query.answer()

# ------------------- Обработка новых callback'ов -------------------
async def handle_ui_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Единый router для всех ui:* callback."""
    query = update.callback_query
    await query.answer()
    data = query.data or ""
    if not data.startswith(UI_PREFIX):
        # Если это не ui:*, возможно старый формат, передаём в старый обработчик
        await handle_reaction_callback(update, context)
        return

    parts = data.split(":")
    scope = parts[1] if len(parts) > 1 else ""
    action = parts[2] if len(parts) > 2 else ""
    args = parts[3:] if len(parts) > 3 else []

    user_id = query.from_user.id

    try:
        if scope == "nav":
            if action == "home":
                await render_dashboard(update, context)
                return
            await send_message_safe(user_id, "🤔 Не знаю такой экран. Вернёмся в меню.")
            await render_dashboard(update, context)
            return

        if scope == "dashboard":
            if action == "notifications":
                await render_notifications_screen(update, context)
                return
            if action == "mentions":
                await render_mentions_screen(update, context)
                return
            if action == "filters":
                await render_filters_screen(update, context)
                return
            if action == "blockers":
                await render_blockers_screen(update, context)
                return
            if action == "settings":
                await render_settings_screen(update, context)
                return
            await send_message_safe(user_id, "🤔 Неизвестное действие.")
            return

        if scope == "cmd":
            cmd = action
            handler = COMMAND_HANDLERS.get(cmd)
            if handler:
                await handler(update, context)
            else:
                await send_message_safe(user_id, f"Команда /{cmd} не найдена.")
            return

        if scope == "notif":
            if action == "ack" and args:
                notif_id = int(args[0])
                notif = await db.get_notification_by_id(notif_id)
                if not notif or notif.get("user_id") != user_id:
                    await send_message_safe(user_id, "❌ Уведомление не найдено.")
                    return
                await db.record_user_reaction(user_id, notif["issue_key"], notif["notification_hash"])
                settings = await _get_fun_settings(user_id)
                if _is_fun_enabled(settings):
                    try:
                        prog = await db.apply_ack_gamification(user_id)
                        xp_gain = prog.get('xp_gain', 0)
                        if xp_gain:
                            await send_message_safe(user_id, f"🏆 +{xp_gain} XP за дисциплину! 🔥 streak {prog.get('streak', 0)}")
                    except Exception:
                        pass
                await query.edit_message_reply_markup(reply_markup=None)
                await send_message_safe(user_id, "✅ Принято. Напоминания по этой задаче остановлены.")
                return

            if action == "mute" and len(args) >= 2:
                filter_id = int(args[0])
                issue_key = args[1]
                filter_name = await db.get_filter_name_by_id(user_id, filter_id)
                if not filter_name:
                    await send_message_safe(user_id, "❌ Фильтр не найден.")
                    return
                ok = await db.mute_task_notifications(user_id, issue_key, filter_name, hours=24)
                if ok:
                    await db.mark_mentions_as_notified(user_id, issue_key)  # для упоминаний не нужно, но оставим
                    await query.edit_message_reply_markup(reply_markup=None)
                    await send_message_safe(user_id, f"🔕 Ок. Не буду напоминать по {issue_key} 24 часа.")
                return

            if action == "open" and len(args) >= 2:
                filter_id = int(args[0])
                issue_key = args[1]
                await render_notification_detail(update, context, filter_id, issue_key)
                return

        if scope == "mention":
            if action == "open" and args:
                issue_key = args[0]
                await render_mention_detail(update, context, issue_key)
                return
            if action == "read" and args:
                issue_key = args[0]
                await db.mark_mentions_as_notified(user_id, issue_key)
                await query.edit_message_reply_markup(reply_markup=None)
                await send_message_safe(user_id, f"✅ Упоминания в {issue_key} отмечены как прочитанные.")
                # Возвращаемся к списку упоминаний
                await render_mentions_screen(update, context)
                return

        if scope == "filter":
            if action == "open" and args:
                filter_id = int(args[0])
                await render_filter_detail(update, context, filter_id)
                return
            if action == "toggle" and args:
                filter_id = int(args[0])
                filter_info = await db.get_filter_by_id(user_id, filter_id)
                if not filter_info:
                    await send_message_safe(user_id, "❌ Фильтр не найден.")
                    return
                new_state = not filter_info["is_active"]
                await db.toggle_filter_active(user_id, filter_info["filter_name"], new_state)
                await render_filter_detail(update, context, filter_id)
                return
            if action == "interval" and args:
                filter_id = int(args[0])
                context.user_data["editing_filter_id"] = filter_id
                context.user_data["pending_cmd"] = "interval"
                await query.edit_message_text(
                    f"⏱ Введите новый интервал (в минутах) для фильтра:",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data=f"filter:open:{filter_id}")]])
                )
                return
            if action == "retention" and args:
                filter_id = int(args[0])
                context.user_data["editing_filter_id"] = filter_id
                context.user_data["pending_cmd"] = "retention"
                await query.edit_message_text(
                    f"♻️ Введите новое количество дней хранения для фильтра:",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data=f"filter:open:{filter_id}")]])
                )
                return
            if action == "edit" and args:
                filter_id = int(args[0])
                filter_info = await db.get_filter_by_id(user_id, filter_id)
                if not filter_info:
                    await send_message_safe(user_id, "❌ Фильтр не найден.")
                    return
                context.user_data["editing_filter_id"] = filter_id
                context.user_data["pending_cmd"] = "editfilter_jql"
                await query.edit_message_text(
                    f"✏️ Введите новый JQL для фильтра <b>{html.escape(filter_info['filter_name'])}</b>:",
                    parse_mode=ParseMode.HTML,
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data=f"filter:open:{filter_id}")]])
                )
                return
            if action == "delete" and args:
                filter_id = int(args[0])
                filter_info = await db.get_filter_by_id(user_id, filter_id)
                if not filter_info:
                    await send_message_safe(user_id, "❌ Фильтр не найден.")
                    return
                await db.delete_user_filter(user_id, filter_info["filter_name"])
                await send_message_safe(user_id, f"✅ Фильтр '{filter_info['filter_name']}' удалён.")
                await render_filters_screen(update, context)
                return

        if scope == "settings":
            if action == "funmode":
                # Просто циклически переключаем
                settings = await db.get_fun_settings(user_id)
                current = settings.get("fun_mode", "off")
                next_mode = {"off": "light", "light": "full", "full": "off"}.get(current, "light")
                await db.set_fun_mode(user_id, next_mode)
                await render_settings_screen(update, context)
                return
            if action == "personality":
                settings = await db.get_fun_settings(user_id)
                current = settings.get("personality", "neutral")
                variants = ["neutral", "developer", "tester", "support"]
                try:
                    next_p = variants[(variants.index(current) + 1) % len(variants)]
                except:
                    next_p = "neutral"
                await db.set_personality(user_id, next_p)
                await render_settings_screen(update, context)
                return
            if action == "whisper":
                settings = await db.get_fun_settings(user_id)
                current = settings.get("whisper_enabled", 1)
                await db.set_whisper_enabled(user_id, not current)
                await render_settings_screen(update, context)
                return
            if action == "zodiac":
                context.user_data["pending_cmd"] = "setzodiac"
                await query.edit_message_text(
                    "🔮 Введите ваш знак зодиака (например, овен):",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Отмена", callback_data=ui_cb("dashboard", "settings"))]])
                )
                return

        if scope == "fun":
            if action == "menu":
                # Пока просто возвращаем на дашборд, можно развить
                await render_dashboard(update, context)
                return

        await send_message_safe(user_id, "🤔 Не понял действие. Вернёмся в меню.")
        await render_dashboard(update, context)

    except Exception as e:
        logger.error(f"UI callback error: {e}")
        await send_message_safe(user_id, "❌ Ошибка обработки действия. Попробуйте ещё раз.")


# ------------------- Команды настройки -------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/start: дашборд"""
    await render_dashboard(update, context)


async def setup_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id

    if user_data.get("jira_user") and user_data.get("jira_token"):
        await send_message_safe(
            user_id,
            "🔧 Вы уже настроили подключение к Jira.\n\n"
            "Если хотите изменить настройки, используйте:\n"
            "/reconfigure - перенастроить Jira\n"
            "/filters - управление фильтрами"
        )
        return ConversationHandler.END

    await send_message_safe(
        user_id,
        "🔧 Настройка подключения к Jira\n\n"
        "Для работы бота нужны:\n"
        "1. Jira Username (ваш логин в Jira)\n"
        "2. Jira API Token (можно получить в настройках Jira)\n\n"
        "Шаг 1 из 2:\n"
        "Отправьте мне ваш Jira Username (обычно это email или логин):"
    )

    session_id = await db.create_session(
        user_id=user_data["user_id"],
        step="setup_jira_user"
    )
    context.user_data["session_id"] = session_id

    return SETUP_JIRA_USER

async def setup_jira_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    jira_user = update.message.text.strip()
    session_id = context.user_data.get("session_id")
    user_id = update.effective_user.id

    if not session_id:
        await send_message_safe(user_id, "❌ Ошибка сессии. Начните заново: /setup")
        return ConversationHandler.END

    await db.update_session(session_id, step="setup_jira_token", data={"jira_user": jira_user})

    await send_message_safe(
        user_id,
        f"✅ Username сохранен: {jira_user}\n\n"
        "Шаг 2 из 2:\n"
        "Отправьте мне ваш Jira API Token:\n\n"
        "Как получить токен:\n"
        "1. Откройте Jira в браузере\n"
        "2. Профиль → Управление аккаунта\n"
        "3. Безопасность → API токены\n"
        "4. Создать токен\n\n"
        "Внимание: Токен будет сохранен в зашифрованном виде."
    )

    return SETUP_JIRA_TOKEN

async def setup_jira_token(update: Update, context: ContextTypes.DEFAULT_TYPE):
    jira_token = update.message.text.strip()
    session_id = context.user_data.get("session_id")
    user_id = update.effective_user.id

    if not session_id:
        await send_message_safe(user_id, "❌ Ошибка сессии. Начните заново: /setup")
        return ConversationHandler.END

    session = await db.get_session(session_id)
    if not session:
        await send_message_safe(user_id, "❌ Сессия устарела. Начните заново: /setup")
        return ConversationHandler.END

    jira_user = session["data"].get("jira_user")
    user_id_db = session["user_id"]

    await send_message_safe(user_id, "🔄 Проверяю подключение к Jira...")

    if await jira_manager.test_user_connection(user_id_db, jira_user, jira_token):
        await db.update_user_jira_credentials(user_id_db, jira_user, jira_token)
        await jira_manager.create_client(user_id_db, jira_user, jira_token)

        await send_message_safe(
            user_id,
            "✅ Подключение к Jira успешно настроено!\n\n"
            f"Напоминания будут приходить каждые {REMINDER_INTERVAL_MINUTES} минут, если не подтвердить уведомление.\n"
            "Ночью (22:00-09:00 МСК) напоминания приостанавливаются.\n\n"
            f"Бот также будет проверять упоминания @{jira_user} каждые {MENTIONS_CHECK_INTERVAL} минут.\n\n"
            "Теперь вы можете:\n"
            "• /addfilter - Добавить фильтр для отслеживания\n"
            "• /filters - Просмотреть ваши фильтры\n"
            "• /checkmentions - Проверить упоминания\n"
            "• /help - Все команды"
        )

        await db.delete_session(session_id)
        if "session_id" in context.user_data:
            del context.user_data["session_id"]

        return ConversationHandler.END
    else:
        await send_message_safe(
            user_id,
            "❌ Не удалось подключиться к Jira\n\n"
            "Проверьте:\n"
            "1. Правильность username и токена\n"
            "2. Доступность Jira сервера\n"
            "3. Не истек ли срок действия токена\n\n"
            "Попробуйте снова: /setup"
        )

        await db.delete_session(session_id)
        if "session_id" in context.user_data:
            del context.user_data["session_id"]

        return ConversationHandler.END

async def reconfigure_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id

    await db.update_user_jira_credentials(user_data["user_id"], None, None)
    await jira_manager.remove_client(user_data["user_id"])

    await send_message_safe(
        user_id,
        "🔄 Настройки Jira сброшены.\n\n"
        "Теперь настройте заново: /setup"
    )

# ------------------- Команды для фильтров -------------------
async def addfilter_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id

    if not user_data.get("jira_user") or not user_data.get("jira_token"):
        await send_message_safe(
            user_id,
            "❌ Сначала настройте подключение к Jira:\n/setup"
        )
        return ConversationHandler.END

    await send_message_safe(
        user_id,
        "📋 Добавление нового фильтра\n\n"
        "Примеры JQL для отслеживания блокировок:\n"
        "-- Все заблокированные задачи, назначенные на меня\n"
        "assignee = currentUser() AND resolution = Unresolved AND issuelinks in blocks()\n\n"
        "-- Задачи, которые я блокирую\n"
        "issuelinks in outwards('Blocks') AND resolution = Unresolved\n\n"
        "-- Активные блокировки в проекте\n"
        "project = PROJ AND status in ('Блокировано', 'В ожидании') AND resolution = Unresolved\n\n"
        "Шаг 1 из 2:\n"
        "Отправьте мне название фильтра (например: Мои блокировки, Блокирующие задачи и т.д.):"
    )

    session_id = await db.create_session(
        user_id=user_data["user_id"],
        step="add_filter_name"
    )
    context.user_data["session_id"] = session_id

    return ADD_FILTER_NAME

async def add_filter_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    filter_name = update.message.text.strip()
    session_id = context.user_data.get("session_id")
    user_id = update.effective_user.id

    if not session_id:
        await send_message_safe(user_id, "❌ Ошибка сессии. Начните заново: /addfilter")
        return ConversationHandler.END

    await db.update_session(session_id, step="add_filter_jql", data={"filter_name": filter_name})

    await send_message_safe(
        user_id,
        f"✅ Название сохранено: {filter_name}\n\n"
        "Шаг 2 из 2:\n"
        "Отправьте мне JQL запрос для этого фильтра.\n\n"
        "Примеры JQL для блокировок:\n"
        "assignee = currentUser() AND resolution = Unresolved AND issuelinks in blocks()\n"
        "project = PROJ AND status = Блокировано\n"
        "created >= -7d AND issuelinks is not empty ORDER BY created DESC\n\n"
        f"Фильтр будет проверяться каждые {DEFAULT_CHECK_INTERVAL} минут.\n"
        "Бонус: Бот автоматически проанализирует все связанные блокирующие задачи!"
    )

    return ADD_FILTER_JQL

async def add_filter_jql(update: Update, context: ContextTypes.DEFAULT_TYPE):
    jql = update.message.text.strip()
    session_id = context.user_data.get("session_id")
    user_id = update.effective_user.id

    if not session_id:
        await send_message_safe(user_id, "❌ Ошибка сессии. Начните заново: /addfilter")
        return ConversationHandler.END

    session = await db.get_session(session_id)
    if not session:
        await send_message_safe(user_id, "❌ Сессия устарела. Начните заново: /addfilter")
        return ConversationHandler.END

    filter_name = session["data"].get("filter_name")
    user_id_db = session["user_id"]

    if await db.add_user_filter(user_id_db, filter_name, jql):
        await send_message_safe(
            user_id,
            f"✅ Фильтр добавлен!\n\n"
            f"Название: {filter_name}\n"
            f"JQL: {jql[:100]}{'...' if len(jql) > 100 else ''}\n\n"
            f"Теперь бот будет проверять этот фильтр каждые {DEFAULT_CHECK_INTERVAL} минут.\n"
            f"Напоминания будут приходить каждые {REMINDER_INTERVAL_MINUTES} минут, если не подтвердить.\n\n"
            f"Особенность: Бот автоматически проанализирует все блокирующие задачи!"
        )
    else:
        await send_message_safe(
            user_id,
            "❌ Ошибка при добавлении фильтра\n\n"
            "Возможно, фильтр с таким названием уже существует.\n"
            "Попробуйте снова: /addfilter"
        )

    await db.delete_session(session_id)
    if "session_id" in context.user_data:
        del context.user_data["session_id"]

    return ConversationHandler.END

async def filters_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Перенаправляем на экран фильтров
    await render_filters_screen(update, context)

async def deletefilter_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not context.args:
        await send_message_safe(
            user_id,
            "❌ Укажите название фильтра:\n/deletefilter НАЗВАНИЕ"
        )
        return

    user_data = await get_user_data(update)
    filter_name = " ".join(context.args)

    if await db.delete_user_filter(user_data["user_id"], filter_name):
        await send_message_safe(user_id, f"✅ Фильтр '{clean_text(filter_name)}' удален.", parse_mode=ParseMode.HTML)
    else:
        await send_message_safe(user_id, f"❌ Фильтр '{clean_text(filter_name)}' не найден.", parse_mode=ParseMode.HTML)

async def togglefilter_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not context.args:
        await send_message_safe(
            user_id,
            "❌ Укажите название фильтра:\n/togglefilter НАЗВАНИЕ"
        )
        return

    user_data = await get_user_data(update)
    filter_name = " ".join(context.args)

    filters = await db.get_user_filters(user_data["user_id"], active_only=False)
    target_filter = next((f for f in filters if f["filter_name"] == filter_name), None)

    if not target_filter:
        await send_message_safe(user_id, f"❌ Фильтр '{clean_text(filter_name)}' не найден.", parse_mode=ParseMode.HTML)
        return

    new_state = not target_filter["is_active"]

    if await db.toggle_filter_active(user_data["user_id"], filter_name, new_state):
        status = "включен" if new_state else "выключен"
        await send_message_safe(user_id, f"✅ Фильтр '{clean_text(filter_name)}' {status}.", parse_mode=ParseMode.HTML)
    else:
        await send_message_safe(user_id, f"❌ Ошибка изменения фильтра '{clean_text(filter_name)}'.", parse_mode=ParseMode.HTML)

async def interval_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    # Проверяем, не пришло ли из pending_cmd
    if "editing_filter_id" in context.user_data:
        filter_id = context.user_data.pop("editing_filter_id")
        filter_info = await db.get_filter_by_id(user_id, filter_id)
        if not filter_info:
            await send_message_safe(user_id, "❌ Фильтр не найден.")
            return
        try:
            interval = int(update.message.text.strip())
        except:
            await send_message_safe(user_id, "❌ Введите число.")
            return
        if interval < 1 or interval > 1440:
            await send_message_safe(user_id, "❌ Интервал должен быть от 1 до 1440 минут.")
            return
        if await db.update_filter_interval(user_id, filter_info["filter_name"], interval):
            await send_message_safe(user_id, f"✅ Интервал для фильтра '{filter_info['filter_name']}' изменён на {interval} мин.")
        else:
            await send_message_safe(user_id, f"❌ Ошибка.")
        # Возвращаемся к деталям фильтра
        await render_filter_detail(update, context, filter_id)
        return

    # Старая логика с аргументами
    if len(context.args) < 2:
        await send_message_safe(
            user_id,
            "❌ Укажите название фильтра и интервал:\n/interval НАЗВАНИЕ МИНУТЫ"
        )
        return

    user_data = await get_user_data(update)
    filter_name = context.args[0]

    try:
        interval = int(context.args[1])
        if interval < 1 or interval > 1440:
            await send_message_safe(user_id, "❌ Интервал должен быть от 1 до 1440 минут.")
            return
    except ValueError:
        await send_message_safe(user_id, "❌ Укажите число минут.")
        return

    if await db.update_filter_interval(user_data["user_id"], filter_name, interval):
        await send_message_safe(
            user_id,
            f"✅ Интервал для фильтра '{clean_text(filter_name)}' изменен на {interval} мин.",
            parse_mode=ParseMode.HTML
        )
    else:
        await send_message_safe(user_id, f"❌ Фильтр '{clean_text(filter_name)}' не найден.", parse_mode=ParseMode.HTML)

async def retention_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if "editing_filter_id" in context.user_data:
        filter_id = context.user_data.pop("editing_filter_id")
        filter_info = await db.get_filter_by_id(user_id, filter_id)
        if not filter_info:
            await send_message_safe(user_id, "❌ Фильтр не найден.")
            return
        try:
            days = int(update.message.text.strip())
        except:
            await send_message_safe(user_id, "❌ Введите число.")
            return
        if days < 1 or days > 365:
            await send_message_safe(user_id, "❌ Количество дней должно быть от 1 до 365.")
            return
        if await db.update_filter_retention(user_id, filter_info["filter_name"], days):
            await send_message_safe(user_id, f"✅ Срок хранения для фильтра '{filter_info['filter_name']}' изменён на {days} дней.")
        else:
            await send_message_safe(user_id, f"❌ Ошибка.")
        await render_filter_detail(update, context, filter_id)
        return

    if len(context.args) < 2:
        await send_message_safe(
            user_id,
            "❌ Укажите название фильтра и количество дней:\n/retention НАЗВАНИЕ ДНИ\n\n"
            "Пример: /retention Мои задачи 10"
        )
        return

    user_data = await get_user_data(update)

    try:
        days = int(context.args[-1])
        if days < 1 or days > 365:
            await send_message_safe(user_id, "❌ Количество дней должно быть от 1 до 365.")
            return
    except ValueError:
        await send_message_safe(user_id, "❌ Последним аргументом должно быть число дней.")
        return

    filter_name = " ".join(context.args[:-1])

    if await db.update_filter_retention(user_data["user_id"], filter_name, days):
        await send_message_safe(
            user_id,
            f"✅ Срок сброса для фильтра '<b>{clean_text(filter_name)}</b>' установлен на {days} дней.\n"
            f"Теперь задачи старше {days} дней будут считаться новыми и вы снова получите по ним уведомления.",
            parse_mode=ParseMode.HTML
        )
    else:
        await send_message_safe(user_id, f"❌ Фильтр '{clean_text(filter_name)}' не найден.", parse_mode=ParseMode.HTML)

async def workstart_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Установить время начала рабочего дня для автоматической очистки старых данных."""
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    user_id_db = user_data["user_id"]
    
    if not context.args:
        current = await db.get_work_start_time(user_id_db)
        if current:
            await send_message_safe(user_id, f"⏰ Ваше время начала рабочего дня: {current} МСК")
        else:
            await send_message_safe(user_id, "⏰ Время начала рабочего дня не задано. Если установить, каждый день в это время будут удаляться старые данные по вашим фильтрам.\n\nУстановите: /workstart 09:00")
        return
    
    time_str = context.args[0].strip()
    import re
    if not re.match(r'^([01]?[0-9]|2[0-3]):[0-5][0-9]$', time_str):
        await send_message_safe(user_id, "❌ Неверный формат. Используйте ЧЧ:ММ (например, 09:00)")
        return
    
    await db.set_work_start_time(user_id_db, time_str)
    await send_message_safe(user_id, f"✅ Время начала рабочего дня установлено: {time_str} МСК\nКаждый день в это время будут удаляться старые данные по вашим фильтрам.")

async def editfilter_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Редактировать JQL фильтра"""
    user_id = update.effective_user.id
    user_data = await get_user_data(update)

    if not context.args:
        filters = await db.get_user_filters(user_data["user_id"], active_only=False)
        if not filters:
            await send_message_safe(user_id, "❌ У вас нет фильтров для редактирования.")
            return
        if len(filters) == 1:
            filter_id = filters[0]["id"]
            context.user_data["editing_filter_id"] = filter_id
            context.user_data["pending_cmd"] = "editfilter_jql"
            await send_message_safe(
                user_id,
                f"✏️ Редактирование фильтра <b>{filters[0]['filter_name']}</b>\n"
                "Введите новый JQL запрос:",
                parse_mode=ParseMode.HTML
            )
        else:
            keyboard = []
            for f in filters:
                keyboard.append([InlineKeyboardButton(
                    f"{'🟢' if f['is_active'] else '🔴'} {f['filter_name']}",
                    callback_data=f"filter:edit:{f['id']}"
                )])
            reply_markup = InlineKeyboardMarkup(keyboard)
            await send_message_safe(
                user_id,
                "Выберите фильтр для редактирования:",
                reply_markup=reply_markup
            )
        return

    filter_name = " ".join(context.args)
    filters = await db.get_user_filters(user_data["user_id"], active_only=False)
    target = next((f for f in filters if f["filter_name"] == filter_name), None)
    if not target:
        await send_message_safe(user_id, f"❌ Фильтр '{filter_name}' не найден.")
        return

    context.user_data["editing_filter_id"] = target["id"]
    context.user_data["pending_cmd"] = "editfilter_jql"
    await send_message_safe(
        user_id,
        f"✏️ Редактирование фильтра <b>{filter_name}</b>\n"
        "Введите новый JQL запрос:",
        parse_mode=ParseMode.HTML
    )

async def editfilter_jql_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик ввода нового JQL при редактировании фильтра"""
    user_id = update.effective_user.id
    filter_id = context.user_data.get("editing_filter_id")
    if not filter_id:
        await send_message_safe(user_id, "❌ Ошибка: не выбран фильтр.")
        return
    new_jql = update.message.text.strip()
    if not new_jql:
        await send_message_safe(user_id, "❌ JQL не может быть пустым.")
        return
    filter_info = await db.get_filter_by_id(user_id, filter_id)
    if not filter_info:
        await send_message_safe(user_id, "❌ Фильтр не найден.")
        return
    success = await db.update_filter_jql(user_id, filter_info["filter_name"], new_jql)
    if success:
        await send_message_safe(
            user_id,
            f"✅ JQL фильтра <b>{filter_info['filter_name']}</b> успешно обновлён.",
            parse_mode=ParseMode.HTML
        )
    else:
        await send_message_safe(
            user_id,
            f"❌ Не удалось обновить фильтр <b>{filter_info['filter_name']}</b>. Проверьте название.",
            parse_mode=ParseMode.HTML
        )
    context.user_data.pop("editing_filter_id", None)
    context.user_data.pop("pending_cmd", None)
    # Вернуться к списку фильтров
    await render_filters_screen(update, context)

# ------------------- Команды для работы с блокировками -------------------
async def blockers_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показать активные блокировки через экран"""
    await render_blockers_screen(update, context)

async def analyze_blockers_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not context.args:
        await send_message_safe(
            user_id,
            "❌ Укажите ключ задачи:\n/blockersinfo TASK-123"
        )
        return

    user_data = await get_user_data(update)
    issue_key = context.args[0].upper()

    client = jira_manager.get_client(user_data["user_id"])
    if not client:
        await send_message_safe(user_id, "❌ Не настроено подключение к Jira")
        return

    await send_message_safe(user_id, f"🔄 Анализирую блокирующие задачи для {issue_key}...")

    try:
        try:
            issue = await client.get_issue(issue_key)
        except JiraAuthError:
            await handle_jira_auth_error(user_data["user_id"])
            return
        except Exception as e:
            logger.error(f"Error getting issue: {e}")
            await send_message_safe(user_id, "❌ Ошибка при получении задачи")
            return

        if not issue:
            await send_message_safe(user_id, f"❌ Задача {issue_key} не найдена")
            return

        blockers_result = smart_watcher.analyze_blockers(
            user_data["user_id"],
            "manual_check",
            issue,
            client
        )
        blockers = await blockers_result if inspect.iscoroutine(blockers_result) else blockers_result

        if not blockers:
            text = f"✅ {issue_key} не имеет блокирующих задач\n\n"
            text += "Эта задача не блокирует другие задачи и не заблокирована другими.\n\n"
            text += f"Прямая ссылка: {client.base_url}/browse/{issue_key}"
        else:
            text = f"🔗 Связанные задачи для {issue_key}:\n\n"
            active_blockers = [b for b in blockers if not b.get("is_resolved", True)]
            resolved_blockers = [b for b in blockers if b.get("is_resolved", False)]

            if active_blockers:
                text += "🚨 Активные блокировки:\n"
                for blocker in active_blockers:
                    assignee_emoji = "👤" if blocker.get("assignee") and blocker["assignee"] != "Не назначен" else "👁"
                    text += f"  • {blocker['key']}\n"
                    text += f"    Сводка: {blocker['summary'][:80]}...\n"
                    text += f"    Статус: {blocker['status']}\n"
                    text += f"    {assignee_emoji} {blocker['assignee']}\n"
                    text += f"    Обновлено: {blocker['updated']}\n\n"

            if resolved_blockers:
                text += "✅ Разрешённые блокировки:\n"
                for blocker in resolved_blockers:
                    text += f"  • {blocker['key']}\n"
                    text += f"    Сводка: {blocker['summary'][:80]}...\n"
                    text += f"    Решение: {blocker.get('resolution', 'Завершена')}\n"
                    text += f"    Обновлено: {blocker['updated']}\n\n"

        keyboard = [
            [InlineKeyboardButton("📂 Открыть основную задачу", url=f"{client.base_url}/browse/{issue_key}")]
        ]
        if blockers:
            keyboard.append([InlineKeyboardButton("🔗 Связанные задачи:", callback_data="noop")])
            for blocker in blockers[:3]:
                status_emoji = "✅" if blocker.get("is_resolved") else "🚨"
                keyboard.append([
                    InlineKeyboardButton(
                        f"{status_emoji} {blocker['key']}",
                        url=f"{client.base_url}/browse/{blocker['key']}"
                    )
                ])

        reply_markup = InlineKeyboardMarkup(keyboard)
        await send_message_safe(user_id, text, reply_markup=reply_markup)

    except Exception as e:
        logger.error(f"Error analyzing blockers: {e}")
        await send_message_safe(user_id, "❌ Ошибка при анализе блокирующих задач")

# ------------------- Команды для работы с упоминаниями -------------------
async def mentions_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await render_mentions_screen(update, context)

async def checkmentions_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id

    if not MENTIONS_ENABLED:
        await send_message_safe(
            user_id,
            "🔔 Отслеживание упоминания отключено в настройках бота."
        )
        return

    client = jira_manager.get_client(user_data["user_id"])
    if not client:
        await send_message_safe(
            user_id,
            "❌ Не настроено подключение к Jira.\n"
            "Сначала настройте бота: /setup"
        )
        return

    await send_message_safe(user_id, "🔄 Проверяю упоминания...")

    try:
        user_info = await db.get_user(user_data["user_id"])
        jira_username = user_info.get("jira_user")

        if not jira_username:
            await send_message_safe(
                user_id,
                "❌ Не удалось определить ваш Jira username.\n"
                "Проверьте настройки: /reconfigure"
            )
            return

        mentions_result = mentions_tracker.check_user_mentions(
            user_data["user_id"],
            client,
            jira_username
        )
        mentions = await mentions_result if inspect.iscoroutine(mentions_result) else mentions_result

        if not mentions:
            await send_message_safe(
                user_id,
                "✅ Новых упоминаний не найдено.\n\n"
                "Бот будет уведомлять вас автоматически, когда вас упомянут (@username) "
                "в комментариях или описаниях задач."
            )
            return

        notified_count = 0
        for mention_info in mentions:
            message_id = await send_mention_notification(user_data["user_id"], mention_info)
            if message_id:
                notified_count += 1

        await send_message_safe(
            user_id,
            f"✅ Найдено {len(mentions)} задач с упоминаниями.\n"
            f"Отправлено {notified_count} уведомлений (по одному на задачу).\n\n"
            f"📊 Всего упоминаний: {sum(m.get('total_mentions', 0) for m in mentions)}"
        )

    except JiraAuthError:
        await handle_jira_auth_error(user_data["user_id"])
    except Exception as e:
        logger.error(f"Error checking mentions: {e}")
        await send_message_safe(user_id, "❌ Ошибка при проверке упоминаний")

async def send_mention_notification(user_id: int, mention_info: Dict[str, Any]) -> Optional[int]:
    try:
        issue = mention_info["issue"]
        issue_key = mention_info["issue_key"]
        fields = issue.get("fields", {})
        mentions = mention_info.get("mentions", [])
        total_mentions = mention_info.get("total_mentions", 0)
        new_mentions_count = mention_info.get("new_mentions_count", total_mentions)

        if new_mentions_count == 0:
            logger.info(f"📭 No NEW mentions for issue {issue_key}, skipping notification")
            return None

        if user_muted.get(user_id, False):
            logger.debug(f"🔇 Skipping mention notification for muted user {user_id}")
            return None

        summary = fields.get("summary", "Без названия")
        status = fields.get("status", {}).get("name", "Неизвестно")
        priority = fields.get("priority", {}).get("name", "Не указан")

        client = jira_manager.get_client(user_id)
        if not client:
            return None

        comment_mentions = [m for m in mentions if m.get("mention_type") == "comment"]
        description_mentions = [m for m in mentions if m.get("mention_type") == "description"]

        unique_mentioners = set()
        for mention in mentions:
            mention_details = mention.get("mention_details", {})
            author = mention_details.get("author") or mention.get("mentioned_by")
            if author:
                unique_mentioners.add(clean_text(author))

        last_mention_text = ""
        last_mention_author = ""
        if comment_mentions:
            last_mention = comment_mentions[0]
            mention_details = last_mention.get("mention_details", {})
            last_mention_text = mention_details.get("body", "")[:200]
            last_mention_author = mention_details.get("author", "Неизвестно")
            if len(mention_details.get("body", "")) > 200:
                last_mention_text += "..."
        elif description_mentions:
            last_mention = description_mentions[0]
            mention_details = last_mention.get("mention_details", {})
            last_mention_text = mention_details.get("text", "")[:200]
            last_mention_author = mention_details.get("author", "Неизвестно")
            if len(mention_details.get("text", "")) > 200:
                last_mention_text += "..."

        text = f"""🔔 Вас упомянули в задаче Jira

Задача: {issue_key} ({client.base_url}/browse/{issue_key})
Сводка: {clean_text(summary)}
Статус: {clean_text(status)}
Приоритет: {clean_text(priority)}

📊 Новых упоминаний: {new_mentions_count} (всего: {total_mentions})
👤 Упомянули: {', '.join(list(unique_mentioners)[:5])}{f' и еще {len(unique_mentioners) - 5}' if len(unique_mentioners) > 5 else ''}

💬 Последнее упоминание от {clean_text(last_mention_author)}:
{clean_text(last_mention_text)}

💡 Нажмите на кнопку ниже, чтобы открыть задачу и увидеть все упоминания.
"""

        keyboard = [
            [InlineKeyboardButton("📂 Открыть задачу", url=f"{client.base_url}/browse/{issue_key}")],
            [InlineKeyboardButton("✅ Увидел", callback_data=ui_cb("mention", "read", issue_key))]
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)

        message_id = await send_message_safe(
            user_id=user_id,
            text=text,
            reply_markup=reply_markup
        )

        if message_id:
            logger.info(f"✅ Mention notification sent for {issue_key} ({new_mentions_count} NEW mentions) to user {user_id}")
            await db.mark_mentions_as_notified(user_id, issue_key)
            return message_id

    except Exception as e:
        logger.error(f"❌ Error sending mention notification: {e}")
        import traceback
        logger.error(traceback.format_exc())

    return None

# ------------------- Дайджест и Инлайн -------------------
async def digest_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    msg = await send_message_safe(user_id, "🔄 Собираю твой дайджест...")
    text = await generate_user_digest(user_data["user_id"])
    if text:
        if msg:
            await send_message_safe(user_id, text, parse_mode=ParseMode.HTML, message_id=msg)
        else:
            await send_message_safe(user_id, text, parse_mode=ParseMode.HTML)
    else:
        await send_message_safe(user_id, "❌ Не удалось собрать данные. Jira настроена?")

async def inline_query_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.inline_query.query.upper().strip()
    if len(query) < 3:
        return

    user_id = update.effective_user.id
    client = jira_manager.get_client(user_id)

    if not client:
        return

    jql = f'(text ~ "{query}*" OR key = "{query}") ORDER BY updated DESC'
    issues_result = client.search(jql, max_results=10)
    issues = await issues_result if inspect.iscoroutine(issues_result) else issues_result

    results = []
    for issue in issues:
        key = issue.get("key")
        fields = issue.get("fields", {})
        summary = fields.get("summary", "Без названия")
        status = fields.get("status", {}).get("name", "Неизвестно")
        url = f"{client.base_url}/browse/{key}"

        assignee_obj = fields.get("assignee")
        assignee_name = assignee_obj.get("displayName", "Не назначен") if assignee_obj else "Не назначен"

        comments = fields.get("comment", {}).get("comments", [])
        last_comment_text = ""
        if comments:
            last_c = comments[-1]
            author = last_c.get("author", {}).get("displayName", "Неизвестно")
            body = last_c.get("body", "")
            if len(body) > 150:
                body = body[:150] + "..."
            last_comment_text = f"\n\n💬 <b>{html.escape(author)}</b>:\n<i>{html.escape(body)}</i>"

        message_text = (
            f"📋 <b><a href='{url}'>{key}</a></b>\n"
            f"{html.escape(summary)}\n\n"
            f"📊 <b>Статус:</b> {status}\n"
            f"👤 <b>Исполнитель:</b> {html.escape(assignee_name)}"
            f"{last_comment_text}"
        )

        description_preview = f"👤 {assignee_name} | {summary}"
        results.append(
            InlineQueryResultArticle(
                id=key,
                title=f"{key} — {status}",
                description=description_preview,
                input_message_content=InputTextMessageContent(
                    message_text,
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True
                )
            )
        )

    await update.inline_query.answer(results, cache_time=10)

# ------------------- Основные команды -------------------
async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    stats = await db.get_user_stats(user_data["user_id"])

    jira_configured = bool(user_data.get("jira_user") and user_data.get("jira_token"))
    jira_status = "✅ Настроено" if jira_configured else "❌ Не настроено"

    muted_status = user_muted.get(user_data["user_id"], False)

    current_time = get_msk_time()

    filters = await db.get_user_filters(user_data["user_id"], active_only=True)
    total_blockers = 0
    blockers_note = ""

    if filters:
        client = jira_manager.get_client(user_data["user_id"])
        if client:
            try:
                all_blockers, truncated = await collect_active_blockers_now(user_data["user_id"], client, filters)
                total_blockers = len(all_blockers)
                if truncated:
                    blockers_note = " (есть ограничение по объёму; см. /blockers)"
            except JiraAuthError:
                # Если токен протух — покажем статус без блокеров и подсветим проблему
                await handle_jira_auth_error(user_data["user_id"])
        else:
            # client может быть не инициализирован на старте; статус всё равно покажем
            pass
    mention_data = await mentions_tracker.get_mention_notification_data(user_data["user_id"])
    unread_mentions = len(mention_data) if mention_data else 0

    text = f"""
📊 Ваш статус

Jira: {jira_status}
Уведомления: {'🔕 Выключены' if muted_status else '🔔 Включены'}
Упоминания: {'🔔 Включены' if MENTIONS_ENABLED else '🔕 Выключены'}
Текущее время: {current_time}

📈 Статистика:
• Фильтров: {stats.get('total_filters', 0)} (активных: {stats.get('active_filters', 0)})
• Отслеживаемых задач: {stats.get('total_tracked', 0)}
• Всего уведомлений: {stats.get('total_notifications', 0)}
• Неподтвержденных: {stats.get('pending_notifications', 0)}
• Непрочитанных упоминаний: {unread_mentions}
• Активных блокировок: {total_blockers}{blockers_note}

⏰ Настройки:
• Интервал напоминаний: {REMINDER_INTERVAL_MINUTES} минут
• Интервал проверки упоминаний: {MENTIONS_CHECK_INTERVAL} минут
• Ночной режим: {'🌙 Включен (22:00-09:00 МСК)' if should_send_reminder_check() else '☀️ Дневное время'}

🔧 Управление:
• /filters - Ваши фильтры
• /blockers - Активные блокировки
• /mentions - Ваши упоминания
• /digest - Утренняя сводка
• /mute - Вкл/выкл все уведомления
• /stats - Подробная статистика
• /pending - Неподтвержденные уведомления
• /nightmode - Информация о ночном режиме
• /workstart - Установить время очистки
"""

    await send_message_safe(user_id, text)

async def mute_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    user_id_db = user_data["user_id"]

    current_state = user_muted.get(user_id_db, False)
    user_muted[user_id_db] = not current_state

    status = "🔕 Все уведомления выключены" if user_muted[user_id_db] else "🔔 Все уведомления включены"
    await send_message_safe(user_id, status)
    logger.info(f"User {user_id_db} muted: {user_muted[user_id_db]}")

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    user_filters = await db.get_user_filters(user_data["user_id"])

    text = "📈 Подробная статистика\n\n"

    if not user_filters:
        text += "У вас пока нет фильтров.\nДобавьте первый: /addfilter"
    else:
        total_blockers = 0
        active_blockers = 0

        for f in user_filters:
            status = "🟢 Активен" if f["is_active"] else "🔴 Неактивен"
            retention = f.get('retention_days') or 30
            text += f"• {f['filter_name']} ({status})\n"
            text += f"  Интервал: {f['check_interval']} мин\n"
            text += f"  Очистка: каждые {retention} дней\n"
            text += f"  JQL: {f['jql'][:60]}{'...' if len(f['jql']) > 60 else ''}\n"

            notifications = await db.get_user_notifications(user_data["user_id"], limit=100)
            filter_notifications = [n for n in notifications if n["filter_name"] == f["filter_name"]]

            filter_blockers = 0
            filter_active = 0

            for notif in filter_notifications:
                details = notif.get("details", {})
                blockers = details.get("blockers", [])
                filter_blockers += len(blockers)
                filter_active += len([b for b in blockers if not b.get("is_resolved", True)])

            text += f"  Блокировок: {filter_blockers} (активных: {filter_active})\n\n"
            total_blockers += filter_blockers
            active_blockers += filter_active

        text += f"\n📊 Общая статистика блокировок:\n"
        text += f"• Всего связанных задач: {total_blockers}\n"
        text += f"• Активных блокировок: {active_blockers}\n"
        text += f"• Решённых: {total_blockers - active_blockers}\n\n"


        # Дополнительно: активные блокировки прямо сейчас в Jira (по активным фильтрам)
        try:
            active_filters = [f for f in user_filters if f.get("is_active")]
            client = jira_manager.get_client(user_data["user_id"])
            if client and active_filters:
                all_blockers_now, truncated = await collect_active_blockers_now(user_data["user_id"], client, active_filters)
                text += f"⏱ Сейчас в Jira активных блокировок: {len(all_blockers_now)}"
                if truncated:
                    text += " (есть ограничение по объёму; см. /blockers)"
                text += "\n\n"
        except Exception:
            pass

    mention_data = await mentions_tracker.get_mention_notification_data(user_data["user_id"])
    unread_mentions = len(mention_data) if mention_data else 0
    total_mentions = await db.get_total_mentions(user_data["user_id"])

    text += f"📨 Статистика упоминаний:\n"
    text += f"• Всего упоминаний: {total_mentions}\n"
    text += f"• Непрочитанных: {unread_mentions}"

    await send_message_safe(user_id, text)

async def pending_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Перенаправляем на экран уведомлений
    await render_notifications_screen(update, context)

async def nightmode_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from .config import NIGHT_MODE_ENABLED, NIGHT_START_HOUR, NIGHT_END_HOUR
    user_id = update.effective_user.id

    current_time = get_msk_time()
    time_until_morning = format_time_until_morning()

    if NIGHT_MODE_ENABLED:
        text = f"""
🌙 Ночной режим бота

Статус: Включен ✅
Текущее время: {current_time}
Ночное время: с {NIGHT_START_HOUR:02d}:00 до {NIGHT_END_HOUR:02d}:00 (МСК)

В ночное время бот:
• ✅ Отправляет уведомления о новых изменениях
• ✅ Отправляет уведомления об упоминаниях
• 🚫 Не отправляет напоминания о неподтвержденных задачах
• 🔄 Продолжает отслеживать изменения в задачах
• ⏰ Напоминания возобновятся автоматически в 09:00 МСК

До утра: {time_until_morning}
Интервал напоминаний: {REMINDER_INTERVAL_MINUTES} минут (в рабочее время)
Интервал упоминаний: {MENTIONS_CHECK_INTERVAL} минут

Команды:
• /mute - полностью отключить уведомления
• /pending - показать неподтвержденные задачи
• /mentions - показать непрочитанные упоминания
• /status - ваш текущий статус
        """
    else:
        text = f"""
🌙 Ночной режим бота

Статус: Выключен 🔔
Текущее время: {current_time}
Интервал напоминаний: {REMINDER_INTERVAL_MINUTES} минут
Интервал упоминаний: {MENTIONS_CHECK_INTERVAL} минут

Бот работает в обычном режиме и отправляет напоминания круглосуточно.

Чтобы включить ночной режим, установите в .env:
NIGHT_MODE_ENABLED=true
NIGHT_START_HOUR=22
NIGHT_END_HOUR=9
        """

    await send_message_safe(user_id, text)


# ------------------- FUN команды -------------------
async def funmode_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    arg = " ".join(context.args).strip().lower() if context.args else ""
    mode = _normalize_fun_mode(arg)
    if not mode:
        # циклим
        current = (await _get_fun_settings(user_data["user_id"])).get("fun_mode", "off")
        mode = {"off": "light", "light": "full", "full": "off"}.get(current, "light")

    await db.set_fun_mode(user_data["user_id"], mode)
    if mode == "off":
        txt = "🧊 Fun-режим выключен. Только работа и никаких мемов 😐"
    elif mode == "light":
        txt = "✨ Fun-режим: LIGHT. Небольшие реакции + аккуратные приколы."
    else:
        txt = "🎭 Fun-режим: FULL. Бот включает характер, реакции и геймификацию."
    await send_message_safe(user_id, txt)

async def personality_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    arg = " ".join(context.args).strip() if context.args else ""
    p = _normalize_personality(arg)
    if not p:
        current = (await _get_fun_settings(user_data["user_id"])).get("personality", "neutral")
        variants = ["neutral", "developer", "tester", "support"]
        try:
            p = variants[(variants.index(current) + 1) % len(variants)]
        except Exception:
            p = "neutral"
    await db.set_personality(user_data["user_id"], p)
    labels = {"neutral": "🙂 нейтральный", "developer": "💻 разработчик", "tester": "🔍 тестировщик", "support": "📩 саппорт"}
    await send_message_safe(user_id, f"🎛 Персона бота: {labels.get(p, p)}")

async def setzodiac_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    zodiac = " ".join(context.args).strip().lower() if context.args else ""
    if not zodiac:
        await send_message_safe(user_id, "Напиши знак зодиака: /setzodiac овен (или телец, близнецы...)")
        return
    if zodiac not in ZODIAC_MAP:
        await send_message_safe(user_id, "🤔 Не узнал знак. Пример: /setzodiac скорпион")
        return
    await db.set_zodiac(user_data["user_id"], zodiac)
    await send_message_safe(user_id, f"🔮 Окей, записал: {zodiac.capitalize()}")

async def horoscope_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    settings = await _get_fun_settings(user_data["user_id"])
    zodiac = settings.get("zodiac")
    if context.args:
        z = " ".join(context.args).strip().lower()
        if z in ZODIAC_MAP:
            zodiac = z
            await db.set_zodiac(user_data["user_id"], z)
    text = await get_random_horoscope(zodiac or "")
    if _is_fun_enabled(settings) and settings.get("whisper_enabled", 1) and not should_send_reminder_check():
        text = _format_whisper(text)
    await send_message_safe(user_id, text, parse_mode=ParseMode.HTML)

async def meme_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    settings = await _get_fun_settings(user_data["user_id"])
    role = (settings.get("personality") or "common")
    if role == "neutral":
        role = "common"
    # можно переопределить аргументом
    if context.args:
        r = context.args[0].strip().lower()
        if r in ROLE_PREFIX:
            role = r
    caption, url = await get_random_meme(role=role)
    # Шепот ночью
    if _is_fun_enabled(settings) and settings.get("whisper_enabled", 1) and not should_send_reminder_check():
        caption = _format_whisper(caption)
    try:
        if url:
            await context.bot.send_photo(chat_id=user_id, photo=url, caption=caption, parse_mode=ParseMode.HTML)
        else:
            await send_message_safe(user_id, caption, parse_mode=ParseMode.HTML)
    except Exception:
        await send_message_safe(user_id, caption, parse_mode=ParseMode.HTML)

async def fact_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    settings = await _get_fun_settings(user_data["user_id"])
    text = await get_random_fact()
    if _is_fun_enabled(settings) and settings.get("whisper_enabled", 1) and not should_send_reminder_check():
        text = _format_whisper(text)
    await send_message_safe(
	    user_id,
	    f"""🧠 Факт дня:
	
	{text}""",
	    parse_mode=ParseMode.HTML
	)

async def whisper_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    settings = await _get_fun_settings(user_data["user_id"])
    cur = bool(settings.get("whisper_enabled", 1))
    arg = " ".join(context.args).strip().lower() if context.args else ""
    if arg in ("on", "1", "true", "да", "вкл"):
        cur = True
    elif arg in ("off", "0", "false", "нет", "выкл"):
        cur = False
    else:
        cur = not cur
    await db.set_whisper_enabled(user_data["user_id"], cur)
    await send_message_safe(user_id, f"🌙 Ночной «шёпот»: {'включён' if cur else 'выключен'}")

async def profile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    s = await _get_fun_settings(user_data["user_id"])
    mode = s.get("fun_mode", "off")
    pers = s.get("personality", "neutral")
    zodiac = s.get("zodiac") or "не задан"
    xp = s.get("xp", 0)
    level = s.get("level", 1)
    streak = s.get("streak", 0)
    whisper = "on" if s.get("whisper_enabled", 1) else "off"
    text = (
        "🎮 <b>Профиль</b>\n\n"
        f"Fun-режим: <b>{mode}</b>\n"
        f"Персона: <b>{pers}</b>\n"
        f"Зодиак: <b>{zodiac}</b>\n"
        f"XP: <b>{xp}</b> | lvl <b>{level}</b> | 🔥 streak <b>{streak}</b>\n"
        f"Ночной «шёпот»: <b>{whisper}</b>\n\n"
        "Команды:\n"
        "• /funmode — переключить режим\n"
        "• /personality — сменить персону\n"
        "• /meme — мем\n"
        "• /horoscope — гороскоп\n"
        "• /setzodiac овен — задать знак\n"
        "• /whisper — шёпот ночью\n"
    )
    await send_message_safe(user_id, text, parse_mode=ParseMode.HTML)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    help_text = f"""
📖 Команды Jira Monitor Bot

Настройка:
/setup - Настроить подключение к Jira
/reconfigure - Перенастроить Jira

Фильтры:
/addfilter - Добавить новый фильтр
/filters - Показать ваши фильтры
/deletefilter &lt;название&gt; - Удалить фильтр
/togglefilter &lt;название&gt; - Вкл/выкл фильтр
/interval &lt;название&gt; &lt;минуты&gt; - Изменить интервал
/retention &lt;название&gt; &lt;дни&gt; - Изменить срок сброса истории фильтра
/editfilter &lt;название&gt; - Редактировать JQL фильтра
/workstart &lt;ЧЧ:ММ&gt; - Установить время очистки старых данных

Блокирующие задачи:
/blockers - Показать все активные блокировки
/blockersinfo TASK-123 - Анализ блокировок для конкретной задачи

Упоминания:
/mentions - Показать ваши упоминания (одно уведомление на задачу)
/checkmentions - Вручную проверить упоминания

Управление и информация:
/digest - Вызвать утреннюю сводку
/status - Ваш статус
/mute - Вкл/выкл все уведомления
/pending - Показать неподтвержденные уведомления
/stats - Подробная статистика
/nightmode - Информация о ночном режиме
/help - Эта справка

📅 Расписание:
• Первое уведомление - сразу при изменении
• Напоминания - каждые {REMINDER_INTERVAL_MINUTES} минут в рабочее время
• Упоминания - каждые {MENTIONS_CHECK_INTERVAL} минут
• Утренний дайджест - 09:00 МСК
• Ночное время (22:00-09:00 МСК) - напоминания не отправляются
• Очистка старых данных - в указанное вами время (если установлено)
"""

    await send_message_safe(user_id, help_text)

# ------------------- Админские команды -------------------
async def adminstats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_data = await get_user_data(update)
    user_id = update.effective_user.id
    from .config import NIGHT_MODE_ENABLED, MENTIONS_ENABLED

    if user_data["user_id"] not in ADMIN_USER_IDS:
        await send_message_safe(user_id, "❌ Эта команда только для администраторов.")
        return

    active_users = await db.get_all_active_users()

    text = f"""
👑 Админская статистика

Всего активных пользователей: {len(active_users)}
Интервал напоминаний: {REMINDER_INTERVAL_MINUTES} минут
Интервал упоминаний: {MENTIONS_CHECK_INTERVAL} минут
Ночной режим: {'Включен' if NIGHT_MODE_ENABLED else 'Выключен'}
Упоминания: {'Включены' if MENTIONS_ENABLED else 'Выключены'}

Пользователи:
"""

    for user in active_users:
        stats = await db.get_user_stats(user["user_id"])
        username = user.get('username', 'нет')
        first_name = user.get('first_name', 'Пользователь')
        text += f"\n• {first_name} (@{username})\n"
        text += f"  ID: {user['user_id']}\n"
        text += f"  Фильтров: {stats.get('total_filters', 0)}\n"
        text += f"  Задач: {stats.get('total_tracked', 0)}\n"
        text += f"  Уведомлений: {stats.get('total_notifications', 0)}\n"
        text += f"  Неподтвержденных: {stats.get('pending_notifications', 0)}\n"
        text += f"  Упоминаний: {stats.get('mentions_count', 0)}\n"

    await send_message_safe(user_id, text)

async def broadcast_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправить сообщение всем активным пользователям (только для админов)

    Важно: берём сырой текст сообщения, чтобы сохранить переносы строк/HTML.
    Пример:
      /broadcast <b>Заголовок</b>\n\nТекст...
    """
    user_id = update.effective_user.id
    if user_id not in ADMIN_USER_IDS:
        await send_message_safe(user_id, "❌ Эта команда только для администраторов.")
        return

    raw = (update.message.text or "").strip() if update.message else ""
    if not raw:
        await send_message_safe(user_id, "❌ Пустое сообщение.")
        return

    # Отрезаем команду /broadcast (с бот-суффиксом тоже)
    # Варианты: /broadcast, /broadcast@MyBot
    m = re.match(r"^/broadcast(?:@\w+)?\s*(.*)$", raw, flags=re.IGNORECASE | re.DOTALL)
    message_text = (m.group(1) if m else "").strip()

    if not message_text:
        await send_message_safe(
            user_id,
            "❌ Укажите текст для рассылки:\n/broadcast Сообщение"
        )
        return

    active_users = await db.get_all_active_users()

    sent_count = 0
    failed_count = 0

    for user in active_users:
        uid = user["user_id"]
        try:
            ok = await send_message_safe(
                uid,
                f"📢 Рассылка:\n\n{message_text}",
                parse_mode=ParseMode.HTML
            )
            if ok:
                sent_count += 1
            else:
                failed_count += 1
            await asyncio.sleep(0.05)
        except Exception as e:
            logger.error(f"Failed to send broadcast to {uid}: {e}")
            failed_count += 1

    await send_message_safe(
        user_id,
        f"✅ Рассылка завершена.\nОтправлено: {sent_count}\nНе удалось: {failed_count}"
    )


async def send_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправить сообщение конкретному пользователю по username или user_id (только для админов)"""
    user_id = update.effective_user.id
    if user_id not in ADMIN_USER_IDS:
        await send_message_safe(user_id, "❌ Эта команда только для администраторов.")
        return

    if len(context.args) < 2:
        await send_message_safe(
            user_id,
            "❌ Укажите получателя и текст:\n/send @username Сообщение\nили\n/send 123456789 Сообщение"
        )
        return

    target = context.args[0]
    message_text = " ".join(context.args[1:])

    if target.startswith('@'):
        username = target[1:].lower()
        conn = await db._get_conn()
        cursor = await conn.execute("SELECT user_id, chat_id FROM users WHERE username = ?", (username,))
        row = await cursor.fetchone()
        if not row:
            await send_message_safe(user_id, f"❌ Пользователь {target} не найден в базе.")
            return
        target_user_id = row["user_id"]
    else:
        try:
            target_user_id = int(target)
        except ValueError:
            await send_message_safe(user_id, "❌ Неверный формат получателя. Используйте @username или числовой ID.")
            return

    success = await send_message_safe(target_user_id, f"📩 Сообщение от админа:\n\n{message_text}")
    if success:
        await send_message_safe(user_id, f"✅ Сообщение отправлено пользователю {target}.")
    else:
        await send_message_safe(user_id, f"❌ Не удалось отправить сообщение пользователю {target}.")

# Словарь обработчиков команд для быстрого доступа
COMMAND_HANDLERS = {
    "setup": setup_cmd,
    "reconfigure": reconfigure_cmd,
    "addfilter": addfilter_cmd,
    "filters": filters_cmd,
    "deletefilter": deletefilter_cmd,
    "togglefilter": togglefilter_cmd,
    "interval": interval_cmd,
    "retention": retention_cmd,
    "editfilter": editfilter_cmd,
    "editfilter_jql": editfilter_jql_handler,
    "workstart": workstart_cmd,
    "blockers": blockers_cmd,
    "blockersinfo": analyze_blockers_cmd,
    "mentions": mentions_cmd,
    "checkmentions": checkmentions_cmd,
    "status": status_cmd,
    "mute": mute_cmd,
    "pending": pending_cmd,
    "stats": stats_cmd,
    "nightmode": nightmode_cmd,
    "digest": digest_cmd,
    "help": help_cmd,
    "adminstats": adminstats_cmd,
    "broadcast": broadcast_cmd,
    "send": send_cmd,

    "funmode": funmode_cmd,
    "personality": personality_cmd,
    "profile": profile_cmd,
    "meme": meme_cmd,
    "horoscope": horoscope_cmd,
    "fact": fact_cmd,
    "whisper": whisper_cmd,
    "setzodiac": setzodiac_cmd,
}

# ------------------- Обработка текстовых сообщений (для ввода параметров) -------------------
async def handle_pending_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обрабатывает ввод параметров для команд, требующих аргументов (вызванных через меню)."""
    if "pending_cmd" in context.user_data:
        cmd = context.user_data.pop("pending_cmd")
        args_text = update.message.text.strip()
        context.args = args_text.split()
        handler = COMMAND_HANDLERS.get(cmd)
        if handler:
            await handler(update, context)
        else:
            await send_message_safe(update.effective_user.id, f"Команда /{cmd} не найдена.")
        return

    # Если не pending_cmd, просто игнорируем (или можно предложить меню)
    await update.message.reply_text("Используйте кнопки меню для навигации.")

# ------------------- FUN helpers -------------------
def _normalize_fun_mode(mode: str) -> str:
    mode = (mode or "").strip().lower()
    if mode in ("0", "off", "disable", "none"):
        return "off"
    if mode in ("1", "light", "lite", "low"):
        return "light"
    if mode in ("2", "full", "max", "on"):
        return "full"
    return ""

def _normalize_personality(p: str) -> str:
    p = (p or "").strip().lower()
    if p in ("dev", "developer", "разраб", "разработчик"):
        return "developer"
    if p in ("qa", "tester", "тестер"):
        return "tester"
    if p in ("support", "саппорт", "поддержка"):
        return "support"
    if p in ("neutral", "обычный", "default"):
        return "neutral"
    return ""

async def _get_fun_settings(user_id: int) -> dict:
    try:
        return await db.get_fun_settings(user_id)
    except Exception:
        return {"fun_mode": "off", "personality": "neutral", "whisper_enabled": 1, "zodiac": None, "xp": 0, "level": 1, "streak": 0}

def _is_fun_enabled(settings: dict) -> bool:
    return (settings or {}).get("fun_mode") in ("light", "full")

def _is_full_fun(settings: dict) -> bool:
    return (settings or {}).get("fun_mode") == "full"

def _format_whisper(text: str) -> str:
    return f"🌙 <i>{text}</i>"

def _status_emotion(status: str) -> str:
    s = (status or "").lower()
    if any(x in s for x in ("done", "готов", "закры", "resolved", "выполн")):
        return "🎉 Ура, оно закрыто! (почти поверил)"
    if any(x in s for x in ("in progress", "в работе", "doing")):
        return "🏃 Поехали, держим темп"
    if any(x in s for x in ("blocked", "заблок", "ожида", "hold")):
        return "🧱 Опа, блокер. Дышим, не паникуем"
    if any(x in s for x in ("to do", "откры", "backlog")):
        return "📝 Задача живёт. Пока что."
    return "🙂"

async def _maybe_add_fun_snippet(user_id: int, base_text: str, status: str, is_reminder: bool, notification_hash: str) -> str:
    settings = await _get_fun_settings(user_id)
    if not _is_fun_enabled(settings):
        return base_text

    # Иногда показываем прогресс в уведомлениях (чтобы не заспамить)
    try:
        show_progress = (int(notification_hash[:2], 16) % 10 == 0) and not is_reminder
    except Exception:
        show_progress = False

    extra_lines = []
    if _is_full_fun(settings) and not is_reminder:
        extra_lines.append(_status_emotion(status))

    if show_progress:
        xp = settings.get("xp", 0)
        level = settings.get("level", 1)
        streak = settings.get("streak", 0)
        extra_lines.append(f"🎮 XP: {xp} | lvl {level} | 🔥 streak {streak}")

    if extra_lines:
        return base_text.rstrip() + "\n" + "\n".join(extra_lines) + "\n"
    return base_text

# ------------------- Функция отправки уведомлений с изменениями (оставлена без изменений) -------------------
async def send_notification_with_changes(user_id: int, filter_name: str,
                                        change_info: Dict[str, Any],
                                        is_reminder: bool = False,
                                        previous_message_id: Optional[int] = None) -> Optional[int]:
    """Отправить уведомление с информацией об изменениях (компактный формат)"""
    if user_muted.get(user_id, False):
        logger.debug(f"🔇 Skipping notification for muted user {user_id}")
        return None

    issue = change_info["issue"]
    issue_key = change_info["issue_key"]
    change_type = change_info["change_type"]
    notification_hash = change_info["notification_hash"]
    blockers = change_info.get("blockers", [])
    changes = change_info.get("changes", {})

    if await db.is_task_muted(user_id, issue_key, filter_name):
        logger.info(f"🔇 Task {issue_key} (filter: {filter_name}) is muted for user {user_id}")
        return None

    if await db.has_user_reacted(user_id, issue_key, notification_hash) and not is_reminder:
        logger.debug(f"✅ User {user_id} already reacted to {issue_key}")
        return None

    if is_reminder and not should_send_reminder_check():
        logger.info(f"🌙 Пропускаем напоминание для user {user_id} - ночное время по МСК")
        return None

    client = jira_manager.get_client(user_id)
    if not client:
        logger.error(f"❌ No Jira client for user {user_id}")
        return None

    fields = issue.get("fields", {})
    summary = fields.get("summary", "Без названия")
    status = fields.get("status", {}).get("name", "Неизвестно")
    priority = fields.get("priority", {}).get("name", "Не указан")
    assignee_data = fields.get("assignee")
    assignee = assignee_data.get("displayName", "Не назначен") if assignee_data else "Не назначен"

    if is_reminder:
        title = f"⏰ Напоминание: задача {issue_key}"
    else:
        title, _ = smart_watcher.get_change_description(changes)
    # Ночной «шёпот» (если fun включен)
    fun_settings = await _get_fun_settings(user_id)
    if _is_fun_enabled(fun_settings) and fun_settings.get("whisper_enabled", 1) and not should_send_reminder_check():
        title = f"🌙 Шёпотом: {title}"


    changes_text = ""
    if changes:
        changes_text = "\n📋 <b>Что изменилось:</b>\n"
        if "status_changed" in changes:
            status_info = changes["status_changed"]
            from_status = status_info["from"] or "нет статуса"
            to_status = status_info["to"] or "неизвестно"
            changes_text += f"• 📊 Статус: {from_status} → {to_status}\n"
        if "new_comments" in changes:
            cnt = len(changes["new_comments"])
            changes_text += f"• 💬 Новых комментариев: {cnt}\n"
        if "updated_comments" in changes:
            cnt = len(changes["updated_comments"])
            changes_text += f"• ✏️ Отредактировано комментариев: {cnt}\n"
        if "new_links" in changes:
            cnt = len(changes["new_links"])
            changes_text += f"• 🔗 Новых связей: {cnt}\n"
        if "assignee_changed" in changes:
            assignee_info = changes["assignee_changed"]
            from_assignee = assignee_info["from"] or "не назначен"
            to_assignee = assignee_info["to"] or "не назначен"
            changes_text += f"• 👤 Исполнитель: {from_assignee} → {to_assignee}\n"
        if "priority_changed" in changes:
            priority_info = changes["priority_changed"]
            from_priority = priority_info["from"] or "не указан"
            to_priority = priority_info["to"] or "не указан"
            emoji = "🚨" if priority_info.get("priority_increased") else "📋"
            changes_text += f"• {emoji} Приоритет: {from_priority} → {to_priority}\n"
        if "blockers_resolved" in changes:
            resolved = changes["blockers_resolved"]
            cnt = len(resolved)
            changes_text += f"• 🎉 Разрешено блокировок: {cnt}\n"
        if "labels_changed" in changes:
            added = changes["labels_changed"].get("added", [])
            if added:
                changes_text += f"• 🏷️ Добавлены метки: {', '.join(added[:3])}\n"
        if "due_date_changed" in changes:
            due = changes["due_date_changed"]
            if due["to"]:
                changes_text += f"• ⏰ Срок: {due['to']}\n"
        if "components_changed" in changes:
            added = changes["components_changed"].get("added", [])
            if added:
                changes_text += f"• 🧩 Добавлены компоненты: {', '.join(added[:3])}\n"

    blockers_text = ""
    active_blockers = [b for b in blockers if not b.get("is_resolved", True)]
    resolved_blockers_list = [b for b in blockers if b.get("is_resolved", False)]

    if active_blockers:
        blockers_text += "\n🚨 <b>Активные блокировки</b> ({}) :\n".format(len(active_blockers))
        for blocker in active_blockers[:3]:
            summary_short = clean_text(blocker.get('summary', ''))[:50]
            assignee_short = clean_text(blocker.get('assignee', 'Не назначен'))[:20]
            blockers_text += f"  • {blocker['key']}: {summary_short}… ({assignee_short})\n"
        if len(active_blockers) > 3:
            blockers_text += f"  ... и еще {len(active_blockers) - 3}\n"

    if resolved_blockers_list:
        blockers_text += "\n✅ <b>Разрешённые блокировки</b> ({}) :\n".format(len(resolved_blockers_list))
        for blocker in resolved_blockers_list[:2]:
            summary_short = clean_text(blocker.get('summary', ''))[:50]
            blockers_text += f"  • {blocker['key']}: {summary_short}…\n"
        if len(resolved_blockers_list) > 2:
            blockers_text += f"  ... и еще {len(resolved_blockers_list) - 2}\n"

    safe_title = clean_text(title)
    safe_filter_name = clean_text(filter_name)
    safe_summary = clean_text(summary)[:100]

    text = f"""{safe_title}

<b>Фильтр:</b> {safe_filter_name}
<b>Задача:</b> {issue_key}
<b>Сводка:</b> {safe_summary}
<b>Статус:</b> {status}
<b>Приоритет:</b> {priority}
<b>Назначена:</b> {assignee}
{changes_text}{blockers_text}
"""

    text = await _maybe_add_fun_snippet(user_id, text, status, is_reminder, notification_hash)
    filter_id = await db.get_filter_id_by_name(user_id, filter_name) or 0

    # Используем новый формат callback
    keyboard = [
        [InlineKeyboardButton("📂 Открыть в Jira", url=f"{client.base_url}/browse/{issue_key}")],
        [
            InlineKeyboardButton("✅ Получил", callback_data=f"notif:ack:0")  # временно, будет заменён после записи
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    message_id = await send_message_safe(
        user_id=user_id,
        text=text,
        reply_markup=reply_markup,
        message_id=previous_message_id
    )

    if message_id:
        notification_details = {
            "summary": safe_summary,
            "status": status,
            "priority": priority,
            "assignee": assignee,
            "changes": changes,
            "blockers_count": len(blockers),
            "active_blockers": len(active_blockers),
            "resolved_blockers": len(resolved_blockers_list),
            "blockers": blockers,
            "is_reminder": is_reminder,
            "message_id": message_id,
            "changes_description": smart_watcher.get_change_description(changes)[1]
        }
        notif_id = await db.record_notification(
            user_id=user_id,
            filter_name=filter_name,
            issue_key=issue_key,
            notification_hash=notification_hash,
            change_type=change_type,
            details=notification_details
        )

        # Обновляем клавиатуру с правильным notif_id
        if notif_id and message_id:
            try:
                new_keyboard = [
                    [InlineKeyboardButton("📂 Открыть в Jira", url=f"{client.base_url}/browse/{issue_key}")],
                    [
                        InlineKeyboardButton("✅ Получил", callback_data=f"notif:ack:{notif_id}"),
                        InlineKeyboardButton("🔕 Не напоминать сутки", callback_data=f"notif:mute:{filter_id}:{issue_key}")
                    ]
                ]
                await context.bot.edit_message_reply_markup(
                    chat_id=user_id,
                    message_id=message_id,
                    reply_markup=InlineKeyboardMarkup(new_keyboard)
                )
            except Exception:
                pass

        logger.info(f"✅ Notification sent to user {user_id}: {issue_key} with changes: {list(changes.keys())}")

        return message_id
    else:
        logger.error(f"❌ Failed to send notification to user {user_id}")
        return None

# ------------------- Проверка всех фильтров задачи -------------------
async def check_all_task_mutes(user_id: int, issue_key: str) -> bool:
    all_notifications = await db.get_notifications_by_issue(user_id, issue_key)
    for notif in all_notifications:
        filter_name = notif["filter_name"]
        if await db.is_task_muted(user_id, issue_key, filter_name):
            logger.info(f"🔍 Task {issue_key} is muted in filter '{filter_name}'")
            return True
    return False

# ------------------- Проверка упоминаний пользователя -------------------
async def check_user_mentions(user_id: int) -> int:
    if not MENTIONS_ENABLED:
        return 0
    try:
        client = jira_manager.get_client(user_id)
        if not client:
            return 0
        user_info = await db.get_user(user_id)
        jira_username = user_info.get("jira_user")
        if not jira_username:
            return 0

        try:
            mentions_result = mentions_tracker.check_user_mentions(user_id, client, jira_username)
            mentions = await mentions_result if inspect.iscoroutine(mentions_result) else mentions_result
        except JiraAuthError:
            await handle_jira_auth_error(user_id)
            return 0
        except Exception as e:
            logger.error(f"Error checking mentions: {e}")
            return 0

        if not mentions:
            return 0

        notified_count = 0
        for mention_info in mentions:
            if await send_mention_notification(user_id, mention_info):
                notified_count += 1
        logger.info(f"✅ Sent {notified_count} mention notifications ({len(mentions)} tasks) to user {user_id}")
        return notified_count
    except Exception as e:
        logger.error(f"❌ Error checking mentions for user {user_id}: {e}")
        return 0

# ------------------- Watcher -------------------
async def check_user_filters(user_id: int) -> int:
    try:
        user_filters = await db.get_user_filters(user_id, active_only=True)
        if not user_filters:
            return 0

        client = jira_manager.get_client(user_id)
        if not client:
            logger.error(f"❌ No Jira client for user {user_id}")
            return 0

        total_notified = 0
        sem = asyncio.Semaphore(3)

        async def process_issue(issue, filter_name):
            async with sem:
                issue_key = issue.get("key")
                if await check_all_task_mutes(user_id, issue_key):
                    logger.info(f"🔇 SKIPPING ENTIRELY: Task {issue_key} is muted in SOME filter for user {user_id}")
                    return 0

                notified = 0
                should_remind, prev_msg_id = await db.should_send_reminder(user_id, filter_name, issue_key)
                if should_remind:
                    last_change_info = await db.get_last_notification_info(user_id, filter_name, issue_key)
                    if last_change_info:
                        logger.info(f"⏰ Sending reminder for {issue_key} to user {user_id}")
                        if await send_notification_with_changes(user_id, filter_name, last_change_info,
                                                                is_reminder=True, previous_message_id=prev_msg_id):
                            notified += 1

                change_info = await smart_watcher.detect_changes_with_blockers(user_id, filter_name, issue, client)
                if change_info:
                    logger.info(f"📨 Change detected with blockers for user {user_id}: {change_info['issue_key']}")
                    if await send_notification_with_changes(user_id, filter_name, change_info):
                        notified += 1
                return notified

        for filter_data in user_filters:
            filter_name = filter_data["filter_name"]
            jql = filter_data["jql"]

            logger.info(f"🔍 Checking filter '{filter_name}' for user {user_id}")
            try:
                issues_result = client.search_with_details(jql)
                issues = await issues_result if inspect.iscoroutine(issues_result) else issues_result
            except JiraAuthError:
                logger.error(f"❌ Jira auth error for user {user_id}")
                await handle_jira_auth_error(user_id)
                return 0
            except Exception as e:
                logger.error(f"Error searching issues for filter {filter_name}: {e}")
                issues = []

            if not issues:
                logger.debug(f"📭 No issues for filter '{filter_name}' (user {user_id})")
                continue

            logger.info(f"📊 Found {len(issues)} issues for filter '{filter_name}' (user {user_id})")

            tasks = [process_issue(issue, filter_name) for issue in issues]
            results = await asyncio.gather(*tasks)
            total_notified += sum(results)

        return total_notified

    except Exception as e:
        logger.error(f"❌ Error checking user {user_id} filters: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return 0

async def jira_watcher():
    logger.info("🚀 Starting multi-user Jira watcher with blocker tracking and mentions...")
    await asyncio.sleep(10)
    logger.info("✅ Watcher started successfully")
    check_counter = 0

    while True:
        try:
            logger.info(f"🔄 Starting check cycle #{check_counter} for all users...")
            active_users = await db.get_all_active_users()

            if not active_users:
                logger.info("📭 No active users found")
                await asyncio.sleep(60)
                continue

            logger.info(f"👥 Checking {len(active_users)} active users")

            semaphore = asyncio.Semaphore(5)

            async def process_user(user):
                async with semaphore:
                    user_id = user["user_id"]
                    if not jira_manager.get_client(user_id):
                        client = await jira_manager.create_client(
                            user_id=user_id,
                            jira_user=user["jira_user"],
                            jira_token=user["jira_token"]
                        )
                    mentions_notified = 0
                    if MENTIONS_ENABLED and check_counter % max(1, MENTIONS_CHECK_INTERVAL // DEFAULT_CHECK_INTERVAL) == 0:
                        mentions_notified = await check_user_mentions(user_id)
                    f_notified = await check_user_filters(user_id)

                    # ЕЖЕДНЕВНАЯ ОЧИСТКА
                    work_start = await db.get_work_start_time(user_id)
                    if work_start:
                        now_msk = get_msk_time_obj()
                        current_time_str = now_msk.strftime("%H:%M")
                        if current_time_str == work_start:
                            last_cleanup = await db.get_last_cleanup_date(user_id)
                            today_str = now_msk.date().isoformat()
                            if last_cleanup != today_str:
                                logger.info(f"🧹 Running daily cleanup for user {user_id} at {work_start}")
                                await db.cleanup_user_old_data(user_id)
                                await db.update_last_cleanup_date(user_id, today_str)

                    return f_notified, mentions_notified

            tasks = [process_user(u) for u in active_users]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            total_notified = 0
            total_mentions = 0

            for r in results:
                if isinstance(r, tuple):
                    total_notified += r[0]
                    total_mentions += r[1]
                elif isinstance(r, Exception):
                    logger.error(f"Error in user task: {r}")

            logger.info(f"✅ Check cycle #{check_counter} completed. Notified: {total_notified}, Mentions: {total_mentions}")
            check_counter += 1
            await asyncio.sleep(DEFAULT_CHECK_INTERVAL * 60)

        except asyncio.CancelledError:
            logger.info("🛑 Watcher cancelled")
            break
        except Exception as e:
            logger.error(f"❌ Error in watcher loop: {e}")
            import traceback
            logger.error(traceback.format_exc())
            await asyncio.sleep(60)

# ------------------- Инициализация пользователей -------------------
async def initialize_user_clients():
    active_users = await db.get_all_active_users()
    logger.info(f"🔧 Initializing Jira clients for {len(active_users)} users...")
    for user in active_users:
        client = await jira_manager.create_client(
            user_id=user["user_id"],
            jira_user=user["jira_user"],
            jira_token=user["jira_token"]
        )
        if client:
            logger.info(f"✅ Client initialized for user {user['user_id']}")
        else:
            logger.error(f"❌ Failed to initialize client for user {user['user_id']}")
    logger.info("✅ User clients initialization completed")

# ------------------- Graceful shutdown -------------------
async def shutdown():
    logger.info("🛑 Shutting down...")
    if watcher_task and not watcher_task.done():
        watcher_task.cancel()
        try:
            await watcher_task
        except asyncio.CancelledError:
            pass
    if digest_task and not digest_task.done():
        digest_task.cancel()
        try:
            await digest_task
        except asyncio.CancelledError:
            pass
    await jira_manager.close_all_clients()
    try:
        await close_http_client()
    except Exception:
        pass
    await db.close()
    logger.info("👋 Shutdown complete")

# ------------------- Основной цикл -------------------
async def main():
    global bot_app, watcher_task, digest_task

    try:
        logger.info("🤖 Starting Multi-User Jira Telegram Bot with blocker tracking and mentions...")
        logger.info(f"📂 Current working directory: {os.getcwd()}")

        # Optional DB backup (older DB versions may not implement it)
        try:
            if hasattr(db, "backup_database"):
                backup_path = await db.backup_database()
                logger.info(f"📦 Database backup created: {backup_path}")
            else:
                logger.warning("📦 Database backup skipped: db.backup_database() not available")
        except Exception as e:
            logger.warning(f"📦 Database backup failed (continuing): {e}")

        try:
            await db.cleanup_old_data(days=30)
        except Exception as e:
            # maintenance не должен валить запуск
            logger.warning(f"⚠️ DB cleanup failed on startup (continuing): {e}")

        bot_app = Application.builder().token(BOT_TOKEN).build()

        setup_conv_handler = ConversationHandler(
            entry_points=[CommandHandler("setup", setup_cmd)],
            states={
                SETUP_JIRA_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, setup_jira_user)],
                SETUP_JIRA_TOKEN: [MessageHandler(filters.TEXT & ~filters.COMMAND, setup_jira_token)],
            },
            fallbacks=[CommandHandler("cancel", cancel_cmd)],
        )

        addfilter_conv_handler = ConversationHandler(
            entry_points=[CommandHandler("addfilter", addfilter_cmd)],
            states={
                ADD_FILTER_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_filter_name)],
                ADD_FILTER_JQL: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_filter_jql)],
            },
            fallbacks=[CommandHandler("cancel", cancel_cmd)],
        )

        bot_app.add_handler(setup_conv_handler)
        bot_app.add_handler(addfilter_conv_handler)
        bot_app.add_handler(CommandHandler("start", start))
        bot_app.add_handler(CommandHandler("reconfigure", reconfigure_cmd))
        bot_app.add_handler(CommandHandler("filters", filters_cmd))
        bot_app.add_handler(CommandHandler("deletefilter", deletefilter_cmd))
        bot_app.add_handler(CommandHandler("togglefilter", togglefilter_cmd))
        bot_app.add_handler(CommandHandler("interval", interval_cmd))
        bot_app.add_handler(CommandHandler("retention", retention_cmd))
        bot_app.add_handler(CommandHandler("editfilter", editfilter_cmd))
        bot_app.add_handler(CommandHandler("workstart", workstart_cmd))
        bot_app.add_handler(CommandHandler("status", status_cmd))
        bot_app.add_handler(CommandHandler("mute", mute_cmd))
        bot_app.add_handler(CommandHandler("stats", stats_cmd))
        bot_app.add_handler(CommandHandler("pending", pending_cmd))
        bot_app.add_handler(CommandHandler("nightmode", nightmode_cmd))
        bot_app.add_handler(CommandHandler("help", help_cmd))

        # Fun
        bot_app.add_handler(CommandHandler("funmode", funmode_cmd))
        bot_app.add_handler(CommandHandler("personality", personality_cmd))
        bot_app.add_handler(CommandHandler("profile", profile_cmd))
        bot_app.add_handler(CommandHandler("meme", meme_cmd))
        bot_app.add_handler(CommandHandler("horoscope", horoscope_cmd))
        bot_app.add_handler(CommandHandler("setzodiac", setzodiac_cmd))
        bot_app.add_handler(CommandHandler("fact", fact_cmd))
        bot_app.add_handler(CommandHandler("whisper", whisper_cmd))
        bot_app.add_handler(CommandHandler("adminstats", adminstats_cmd))

        bot_app.add_handler(CommandHandler("blockers", blockers_cmd))
        bot_app.add_handler(CommandHandler("blockersinfo", analyze_blockers_cmd))

        bot_app.add_handler(CommandHandler("mentions", mentions_cmd))
        bot_app.add_handler(CommandHandler("checkmentions", checkmentions_cmd))

        bot_app.add_handler(CommandHandler("broadcast", broadcast_cmd))
        bot_app.add_handler(CommandHandler("send", send_cmd))

        bot_app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_pending_command))

        bot_app.add_handler(CallbackQueryHandler(handle_ui_callback))

        bot_app.add_handler(CommandHandler("digest", digest_cmd))
        bot_app.add_handler(InlineQueryHandler(inline_query_handler))

        await bot_app.initialize()
        await bot_app.start()
        await bot_app.updater.start_polling()

        logger.info("✅ Telegram bot started and listening")

        await initialize_user_clients()

        watcher_task = asyncio.create_task(jira_watcher())
        digest_task = asyncio.create_task(daily_digest_scheduler(bot_app))

        logger.info("✅ Bot is fully operational with blocker tracking, mentions, digests and inline mode!")

        await asyncio.gather(watcher_task, digest_task)

    except KeyboardInterrupt:
        logger.info("🛑 Bot stopped by user")
    except Exception as e:
        logger.error(f"💥 Fatal error: {e}")
        import traceback
        logger.error(traceback.format_exc())
    finally:
        await shutdown()

if __name__ == "__main__":
    asyncio.run(main())