# jira_manager.py
import logging
import asyncio
from typing import Dict, Optional, List
from .jira_client import JiraClient

logger = logging.getLogger(__name__)

class JiraManager:
    def __init__(self):
        self.user_clients: Dict[int, JiraClient] = {}
        logger.info("✅ JiraManager initialized")
    
    async def create_client(self, user_id: int, jira_user: str, jira_token: str, 
                     base_url: str = None) -> Optional[JiraClient]:
        try:
            from .config import JIRA_BASE_URL
            base_url = base_url or JIRA_BASE_URL
            
            client = JiraClient(
                base_url=base_url,
                username=jira_user,
                token=jira_token
            )
            
            if await client.test_connection():
                if user_id in self.user_clients:
                    await self.user_clients[user_id].close()
                
                self.user_clients[user_id] = client
                logger.info(f"✅ Async Jira client created for user {user_id}")
                return client
            else:
                logger.error(f"❌ Failed to create Async Jira client for user {user_id}")
                await client.close()
                return None
                
        except Exception as e:
            logger.error(f"❌ Error creating Async Jira client: {e}")
            return None
    
    def get_client(self, user_id: int) -> Optional[JiraClient]:
        return self.user_clients.get(user_id)
    
    async def remove_client(self, user_id: int):
        if user_id in self.user_clients:
            client = self.user_clients.pop(user_id)
            await client.close()
            logger.info(f"🗑️ Removed and closed Jira client for user {user_id}")
    
    async def test_user_connection(self, user_id: int, jira_user: str, 
                            jira_token: str) -> bool:
        try:
            from .config import JIRA_BASE_URL
            
            temp_client = JiraClient(
                base_url=JIRA_BASE_URL,
                username=jira_user,
                token=jira_token
            )
            
            success = await temp_client.test_connection()
            await temp_client.close()
            return success
            
        except Exception as e:
            logger.error(f"❌ Error testing user connection: {e}")
            return False

    async def close_all_clients(self):
        """Закрыть все Jira-клиенты (например, при shutdown)."""
        for user_id, client in list(self.user_clients.items()):
            try:
                await client.close()
            except Exception as e:
                logger.error(f"❌ Error closing Jira client for user {user_id}: {e}")
        self.user_clients.clear()


jira_manager = JiraManager()