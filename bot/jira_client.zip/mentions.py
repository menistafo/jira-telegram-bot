# mentions.py
import logging
import re
import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from .db import db

logger = logging.getLogger(__name__)

class MentionsTracker:
    def __init__(self):
        self.db = db
        logger.info("✅ MentionsTracker initialized")
    
    async def check_user_mentions(self, user_id: int, jira_client, jira_username: str) -> List[Dict]:
        """Проверить упоминания пользователя в Jira (группированные по задачам)"""
        try:
            # Получаем время последней проверки
            last_check = self.db.get_last_mention_check_time(user_id)
            
            # Ищем задачи с упоминаниями, исключая закрытые задачи
            issues = jira_client.search_mentions_batch(
                jira_username, 
                last_check, 
                batch_size=5,
                exclude_resolved=True  # Исключаем закрытые задачи!
            )
            
            if not issues:
                return []
            
            all_mentions = []
            
            # Ограничиваем количество обрабатываемых задач для первого запуска
            max_issues_to_process = 20 if not last_check else 50
            
            for i, issue in enumerate(issues[:max_issues_to_process]):
                issue_key = issue.get("key")
                status_name = issue.get("fields", {}).get("status", {}).get("name", "")
                
                # Двойная проверка статуса (на всякий случай)
                if jira_client.is_resolved_status(status_name):
                    logger.info(f"⚠️ Skipping resolved issue {issue_key} (status: {status_name})")
                    continue
                
                logger.info(f"Processing active issue {i+1}/{min(len(issues), max_issues_to_process)}: {issue_key} (status: {status_name})")
                
                try:
                    # Получаем полную информацию о задаче с комментариями
                    issue_details = jira_client.get_issue_with_comments(issue_key)
                    
                    if not issue_details:
                        logger.warning(f"Skipping issue {issue_key} - failed to get details")
                        continue
                    
                    fields = issue_details.get("fields", {})
                    comments = fields.get("comment", {}).get("comments", [])
                    
                    # Ищем упоминания в комментариях
                    comment_mentions = await self.find_mentions_in_comments_async(comments, jira_username)
                    
                    # Проверяем описание
                    description = fields.get("description", "")
                    description_mentions = []
                    
                    if description and self.has_mention(description, jira_username):
                        description_mentions.append({
                            "type": "description",
                            "text": description[:500],
                            "author": fields.get("reporter", {}).get("displayName", "Неизвестно"),
                            "created": fields.get("created")
                        })
                    
                    # СОБИРАЕМ ВСЕ УПОМИНАНИЯ ДЛЯ ЭТОЙ ЗАДАЧИ В ОДНУ ГРУППУ
                    if comment_mentions or description_mentions:
                        mentions_for_issue = []
                        
                        # Сохраняем упоминания из комментариев
                        for mention in comment_mentions:
                            saved = self.db.save_mention(
                                user_id=user_id,
                                issue_key=issue_key,
                                comment_id=mention["comment_id"],
                                mentioned_by=mention["author"],
                                mention_text=mention["body"],
                                mention_type=mention["type"]
                            )
                            if saved:
                                mentions_for_issue.append({
                                    "mention_type": "comment",
                                    "mention_details": mention
                                })
                        
                        # Сохраняем упоминания из описания
                        for mention in description_mentions:
                            saved = self.db.save_mention(
                                user_id=user_id,
                                issue_key=issue_key,
                                mentioned_by=mention["author"],
                                mention_text=mention["text"],
                                mention_type="description"
                            )
                            if saved:
                                mentions_for_issue.append({
                                    "mention_type": "description",
                                    "mention_details": mention
                                })
                        
                        # ЕСЛИ ЕСТЬ УПОМИНАНИЯ - ДОБАВЛЯЕМ ОДНУ ЗАПИСЬ О ЗАДАЧЕ
                        if mentions_for_issue:
                            all_mentions.append({
                                "issue": issue,
                                "issue_key": issue_key,
                                "mentions": mentions_for_issue,  # Все упоминания в этой задаче
                                "total_mentions": len(mentions_for_issue)
                            })
                        
                        logger.info(f"Found {len(mentions_for_issue)} mentions in issue {issue_key}")
                    
                    # Пауза между обработкой задач чтобы не перегружать сервер
                    if i % 5 == 0 and i > 0:
                        await asyncio.sleep(1)
                        
                except Exception as e:
                    logger.error(f"Error processing issue {issue_key}: {e}")
                    continue
            
            logger.info(f"📨 Found {len(all_mentions)} issues with mentions for user {user_id}")
            return all_mentions  # Возвращаем список задач с упоминаниями
            
        except Exception as e:
            logger.error(f"❌ Error checking mentions for user {user_id}: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return []
    
    async def find_mentions_in_comments_async(self, comments: List[Dict], username: str) -> List[Dict]:
        """Асинхронный поиск упоминаний в комментариях"""
        user_mentions = []
        
        for comment in comments:
            comment_body = comment.get("body", "")
            comment_id = comment.get("id")
            comment_author = comment.get("author", {}).get("displayName", "Неизвестно")
            
            # Проверяем наличие упоминания
            if self.has_mention(comment_body, username):
                mention_info = {
                    "comment_id": comment_id,
                    "author": comment_author,
                    "body": comment_body[:500],
                    "created": comment.get("created"),
                    "updated": comment.get("updated"),
                    "type": "comment"
                }
                user_mentions.append(mention_info)
        
        return user_mentions
    
    def has_mention(self, text: str, username: str) -> bool:
        """Проверить, есть ли упоминание пользователя в тексте"""
        if not text:
            return False
        
        # Приводим к нижнему регистру для поиска
        text_lower = text.lower()
        username_lower = username.lower()
        
        # Проверяем разные форматы упоминаний
        patterns = [
            f"@{username_lower}",  # @username
            f"[~{username_lower}]",  # [~username] - Jira format
            f"@({username_lower}[^\\w@-]|{username_lower}$)",  # @username с границей слова
        ]
        
        for pattern in patterns:
            if re.search(pattern, text_lower):
                return True
        
        # Также проверяем точное совпадение (если username содержит спецсимволы)
        if f"@{username}" in text:
            return True
            
        return False
    
    def get_mention_notification_data(self, user_id: int) -> List[Dict[str, Any]]:
        """Получить данные для уведомлений об упоминаниях (группированные по задачам)"""
        try:
            # Получаем непрочитанные упоминания, сгруппированные по задачам
            query = """
            SELECT 
                issue_key,
                COUNT(*) as mention_count,
                GROUP_CONCAT(DISTINCT mentioned_by) as mentioners,
                MAX(created_at) as last_mention
            FROM user_mentions 
            WHERE user_id = ? AND notification_sent = 0
            GROUP BY issue_key
            ORDER BY last_mention DESC
            """
            
            self.db.cursor.execute(query, (user_id,))
            rows = self.db.cursor.fetchall()
            
            issues_data = []
            for row in rows:
                issue_key = row["issue_key"]
                mention_count = row["mention_count"]
                mentioners = row["mentioners"] or ""
                
                # Получаем детали упоминаний для этой задачи
                details_query = """
                SELECT comment_id, mentioned_by, mention_text, mention_type, created_at
                FROM user_mentions 
                WHERE user_id = ? AND issue_key = ? AND notification_sent = 0
                ORDER BY created_at DESC
                LIMIT 5
                """
                
                self.db.cursor.execute(details_query, (user_id, issue_key))
                details_rows = self.db.cursor.fetchall()
                
                mentions_list = []
                for detail in details_rows:
                    mentions_list.append({
                        "comment_id": detail["comment_id"],
                        "mentioned_by": detail["mentioned_by"],
                        "mention_text": detail["mention_text"][:200] if detail["mention_text"] else "",
                        "mention_type": detail["mention_type"],
                        "created_at": detail["created_at"]
                    })
                
                issues_data.append({
                    "issue_key": issue_key,
                    "total_mentions": mention_count,
                    "mentioners": mentioners.split(",") if mentioners else [],
                    "last_mention": row["last_mention"],
                    "mentions": mentions_list
                })
            
            return issues_data
            
        except Exception as e:
            logger.error(f"Error getting mention notification data: {e}")
            return []

# Создаем глобальный экземпляр трекера упоминаний
mentions_tracker = MentionsTracker()