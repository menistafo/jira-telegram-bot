# db.py
import sqlite3
import json
import logging
import hashlib
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_path: str = None, encryption_key: Optional[bytes] = None):
        # В Docker используем абсолютный путь
        if db_path is None:
            # Для Docker: используем /app/bot/data как стандартный путь
            # Но также проверяем переменную окружения DATABASE_PATH
            db_path = os.getenv("DATABASE_PATH", "/app/bot/data/jira_bot.db")
        
        self.db_path = os.path.abspath(db_path)
        logger.info(f"📂 Database path: {self.db_path}")
        
        # Создаем папку для файла базы, если нужно
        data_dir = os.path.dirname(self.db_path)
        os.makedirs(data_dir, exist_ok=True)
        
        # Создаем папку для бэкапов
        backup_dir = os.path.join(data_dir, "backups")
        os.makedirs(backup_dir, exist_ok=True)
        
        # Даем права на запись (важно для Docker)
        try:
            os.chmod(data_dir, 0o777)  # Полные права для отладки
            os.chmod(backup_dir, 0o777)
            logger.info(f"📁 Data directory permissions set: {data_dir}")
        except Exception as e:
            logger.warning(f"⚠️ Could not set permissions: {e}")
        
        # Проверяем существование файла базы
        if os.path.exists(self.db_path):
            db_size = os.path.getsize(self.db_path)
            logger.info(f"📊 Existing database file size: {db_size} bytes")
        else:
            logger.info(f"📝 Creating new database file")
        
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()
        
        # Инициализация шифрования
        if encryption_key:
            self.cipher = Fernet(encryption_key)
            logger.info("🔑 Using provided encryption key")
        else:
            # Генерируем ключ для тестов (в проде должен быть задан в конфигурации)
            # Сохраняем ключ в файл для постоянного использования
            key_path = os.path.join(data_dir, "encryption.key")
            
            if os.path.exists(key_path):
                # Читаем существующий ключ
                with open(key_path, 'rb') as f:
                    key = f.read()
                logger.info(f"🔑 Loaded encryption key from file: {key_path}")
            else:
                # Генерируем новый ключ
                key = Fernet.generate_key()
                with open(key_path, 'wb') as f:
                    f.write(key)
                # Даем права на файл ключа
                try:
                    os.chmod(key_path, 0o600)
                except:
                    pass
                logger.info(f"🔑 Generated new encryption key and saved to: {key_path}")
            
            self.cipher = Fernet(key)
        
        self.initialize()
    
    def initialize(self):
        """Инициализировать базу данных, создать таблицы если их нет"""
        logger.info("🔄 Initializing database...")
        
        # Сначала проверяем существующие таблицы
        self._verify_existing_tables()
        
        # Таблица пользователей
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            chat_id INTEGER,
            jira_user TEXT,
            jira_token TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            is_active INTEGER DEFAULT 1
        )
        ''')
        
        # Таблица сессий (для диалогов)
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS sessions (
            session_id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            step TEXT NOT NULL,
            data TEXT,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
        ''')
        
        # Таблица фильтров пользователей
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_filters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            filter_name TEXT NOT NULL,
            jql TEXT NOT NULL,
            check_interval INTEGER DEFAULT 5,
            is_active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(user_id, filter_name),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
        ''')
        
        # Таблица для хранения уведомлений
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            filter_name TEXT NOT NULL,
            issue_key TEXT NOT NULL,
            notification_hash TEXT NOT NULL,
            change_type TEXT NOT NULL,
            details TEXT,
            message_id INTEGER,
            is_reminder INTEGER DEFAULT 0,
            user_reaction TEXT,
            reaction_time TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
        ''')
        
        # Таблица для временно отключенных уведомлений
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS muted_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            issue_key TEXT NOT NULL,
            filter_name TEXT NOT NULL,
            muted_until TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
        ''')
        
        # Таблица для хранения истории задач
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS issue_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            filter_name TEXT NOT NULL,
            issue_key TEXT NOT NULL,
            issue_data TEXT NOT NULL,
            issue_hash TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
        ''')
        
        # НОВАЯ таблица для упоминаний пользователей
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_mentions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            issue_key TEXT NOT NULL,
            comment_id TEXT,
            mentioned_by TEXT,
            mention_text TEXT,
            mention_type TEXT,
            notification_sent INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, issue_key, comment_id),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
        ''')
        
        # Создаем индексы для быстрого поиска
        self._create_indexes()
        
        self.conn.commit()
        
        # Проверяем существование колонок и добавляем если нужно
        self._check_and_add_columns()
        
        # Проверяем структуру таблиц
        self._verify_table_structure()
        
        logger.info("✅ Database initialized successfully")
    
    def _verify_existing_tables(self):
        """Проверить существующие таблицы перед инициализацией"""
        try:
            self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in self.cursor.fetchall()]
            logger.info(f"📊 Existing tables: {tables}")
            
            # Проверяем количество записей в таблицах
            for table in ['users', 'user_filters', 'notifications', 'issue_history', 'muted_tasks', 'sessions', 'user_mentions']:
                if table in tables:
                    self.cursor.execute(f"SELECT COUNT(*) as count FROM {table}")
                    count = self.cursor.fetchone()['count']
                    logger.info(f"  {table}: {count} records")
                
        except Exception as e:
            logger.error(f"❌ Error checking existing tables: {e}")
    
    def _create_indexes(self):
        """Создать индексы для быстрого поиска"""
        indexes = [
            ('idx_users_user_id', 'users', 'user_id'),
            ('idx_users_chat_id', 'users', 'chat_id'),
            ('idx_sessions_user_id', 'sessions', 'user_id'),
            ('idx_user_filters_user_id', 'user_filters', 'user_id'),
            ('idx_user_filters_active', 'user_filters', 'user_id, is_active'),
            ('idx_notifications_user', 'notifications', 'user_id'),
            ('idx_notifications_issue', 'notifications', 'issue_key'),
            ('idx_notifications_hash', 'notifications', 'user_id, notification_hash'),
            ('idx_notifications_reaction', 'notifications', 'user_id, issue_key, user_reaction'),
            ('idx_muted_tasks_user', 'muted_tasks', 'user_id, issue_key, filter_name'),
            ('idx_issue_history_user', 'issue_history', 'user_id, filter_name, issue_key'),
            ('idx_issue_history_hash', 'issue_history', 'user_id, filter_name, issue_key, issue_hash'),
            # Индексы для упоминаний
            ('idx_user_mentions_user', 'user_mentions', 'user_id'),
            ('idx_user_mentions_notification', 'user_mentions', 'user_id, notification_sent'),
            ('idx_user_mentions_issue', 'user_mentions', 'issue_key'),
        ]
        
        for idx_name, table, columns in indexes:
            try:
                self.cursor.execute(f"CREATE INDEX IF NOT EXISTS {idx_name} ON {table}({columns})")
                logger.debug(f"Created index {idx_name} on {table}({columns})")
            except Exception as e:
                logger.error(f"Error creating index {idx_name}: {e}")
    
    def _check_and_add_columns(self):
        """
        Проверить существование всех необходимых колонок и добавить если их нет.
        Это для совместимости с существующими базами.
        """
        try:
            # Словарь таблиц и колонок, которые нужно проверить
            tables_to_check = {
                'notifications': [
                    ('message_id', 'INTEGER'),
                    ('is_reminder', 'INTEGER DEFAULT 0'),
                    ('user_reaction', 'TEXT'),
                    ('reaction_time', 'TEXT'),
                ],
                'muted_tasks': [
                    ('muted_until', 'TEXT'),
                ],
                'user_mentions': [
                    ('mention_type', 'TEXT'),
                ]
            }
            
            for table_name, columns in tables_to_check.items():
                # Проверяем существование таблицы
                self.cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
                if not self.cursor.fetchone():
                    logger.info(f"Table {table_name} doesn't exist, skipping column check")
                    continue
                
                # Получаем существующие колонки
                self.cursor.execute(f"PRAGMA table_info({table_name})")
                existing_columns = [col[1] for col in self.cursor.fetchall()]
                
                for column_name, column_type in columns:
                    if column_name not in existing_columns:
                        logger.info(f"Adding column {column_name} to table {table_name}")
                        try:
                            self.cursor.execute(f'ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}')
                            logger.info(f"✅ Column {column_name} added to table {table_name}")
                        except sqlite3.OperationalError as e:
                            if "duplicate column name" in str(e):
                                logger.info(f"Column {column_name} already exists in table {table_name}")
                            else:
                                raise
            
            self.conn.commit()
            logger.info("✅ Database columns checked and updated")
            
        except Exception as e:
            logger.error(f"❌ Error checking/adding columns: {e}")
    
    def _verify_table_structure(self):
        """Проверить структуру таблиц"""
        expected_tables = ['users', 'user_filters', 'notifications', 
                          'issue_history', 'muted_tasks', 'sessions', 'user_mentions']
        
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        existing_tables = [row[0] for row in self.cursor.fetchall()]
        
        logger.info(f"📊 Final table check - Existing tables: {existing_tables}")
        
        for table in expected_tables:
            if table not in existing_tables:
                logger.warning(f"⚠️ Table {table} is missing, will be created on demand")
            else:
                # Проверяем количество записей
                self.cursor.execute(f"SELECT COUNT(*) as count FROM {table}")  
                count = self.cursor.fetchone()['count']
                logger.info(f"  {table}: {count} records")
    
    # ------------------- Методы шифрования -------------------
    def _encrypt(self, data: str) -> str:
        """Зашифровать данные"""
        if not data:
            return ""
        encrypted = self.cipher.encrypt(data.encode())
        return encrypted.decode()
    
    def _decrypt(self, data: str) -> str:
        """Расшифровать данные"""
        if not data:
            return ""
        try:
            decrypted = self.cipher.decrypt(data.encode())
            return decrypted.decode()
        except Exception as e:
            logger.error(f"Error decrypting data: {e}")
            return ""
    
    # ------------------- Методы пользователей -------------------
    def get_or_create_user(self, user_id: int, username: str = None, 
                         first_name: str = None, last_name: str = None,
                         chat_id: int = None) -> Dict[str, Any]:
        """Получить или создать пользователя"""
        query = "SELECT * FROM users WHERE user_id = ?"
        self.cursor.execute(query, (user_id,))
        user = self.cursor.fetchone()
        
        now = datetime.now().isoformat()
        
        if user:
            # Обновляем данные пользователя если изменились
            update_fields = []
            update_values = []
            
            if username and username != user["username"]:
                update_fields.append("username = ?")
                update_values.append(username)
            
            if first_name and first_name != user["first_name"]:
                update_fields.append("first_name = ?")
                update_values.append(first_name)
            
            if last_name and last_name != user["last_name"]:
                update_fields.append("last_name = ?")
                update_values.append(last_name)
            
            if chat_id and chat_id != user["chat_id"]:
                update_fields.append("chat_id = ?")
                update_values.append(chat_id)
            
            if update_fields:
                update_fields.append("updated_at = ?")
                update_values.append(now)
                update_values.append(user_id)
                
                update_query = f"UPDATE users SET {', '.join(update_fields)} WHERE user_id = ?"
                self.cursor.execute(update_query, update_values)
                self.conn.commit()
            
            # Получаем обновленные данные
            self.cursor.execute(query, (user_id,))
            user = self.cursor.fetchone()
            
            result = dict(user)
            # Расшифровываем токен если он есть
            if result.get("jira_token"):  
                result["jira_token"] = self._decrypt(result["jira_token"])
            
            return result
        else:
            # Создаем нового пользователя
            query = """
            INSERT INTO users 
            (user_id, username, first_name, last_name, chat_id, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """
            self.cursor.execute(query, (
                user_id, username, first_name, last_name, chat_id, now, now
            ))
            self.conn.commit()
            
            logger.info(f"👤 Created new user: {user_id} ({username})")
            
            return {
                "user_id": user_id,
                "username": username,
                "first_name": first_name,
                "last_name": last_name,
                "chat_id": chat_id,
                "jira_user": None,
                "jira_token": None,
                "created_at": now,
                "updated_at": now,
                "is_active": 1
            }
    
    def get_user(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Получить пользователя по ID"""
        query = "SELECT * FROM users WHERE user_id = ?"
        self.cursor.execute(query, (user_id,))
        user = self.cursor.fetchone()
        
        if user:
            result = dict(user)
            # Расшифровываем токен если он есть
            if result.get("jira_token"):
                result["jira_token"] = self._decrypt(result["jira_token"])
            return result
        
        return None
    
    def update_user_jira_credentials(self, user_id: int, jira_user: str, jira_token: str):
        """Обновить Jira credentials пользователя"""
        now = datetime.now().isoformat()
        
        # Шифруем токен
        encrypted_token = self._encrypt(jira_token) if jira_token else None
        
        query = """
        UPDATE users 
        SET jira_user = ?, jira_token = ?, updated_at = ?, is_active = 1
        WHERE user_id = ?
        """
        self.cursor.execute(query, (jira_user, encrypted_token, now, user_id))
        self.conn.commit()
        
        logger.info(f"🔑 Updated Jira credentials for user {user_id}")
        
        return self.cursor.rowcount > 0
    
    def get_all_active_users(self) -> List[Dict[str, Any]]:
        """Получить всех активных пользователей с настройками Jira"""
        query = """
        SELECT * FROM users 
        WHERE is_active = 1 
        AND jira_user IS NOT NULL 
        AND jira_token IS NOT NULL
        AND chat_id IS NOT NULL
        """
        self.cursor.execute(query)
        rows = self.cursor.fetchall()
        
        users = []
        for row in rows:
            user = dict(row)
            # Расшифровываем токен
            if user.get("jira_token"):
                user["jira_token"] = self._decrypt(user["jira_token"])
            users.append(user)
        
        logger.info(f"👥 Found {len(users)} active users")
        return users
    
    def deactivate_user(self, user_id: int):
        """Деактивировать пользователя"""
        query = "UPDATE users SET is_active = 0 WHERE user_id = ?"
        self.cursor.execute(query, (user_id,))
        self.conn.commit()
        
        logger.info(f"👤 Deactivated user {user_id}")
        
        return self.cursor.rowcount > 0
    
    # ------------------- Методы сессий -------------------
    def create_session(self, user_id: int, step: str, data: Dict = None, 
                      expires_in: int = 3600) -> str:
        """Создать новую сессию"""
        import uuid
        session_id = str(uuid.uuid4())
        now = datetime.now()
        expires_at = (now + timedelta(seconds=expires_in)).isoformat()
        
        data_json = json.dumps(data) if data else "{}"
        
        query = """
        INSERT INTO sessions (session_id, user_id, step, data, created_at, expires_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """
        self.cursor.execute(query, (
            session_id, user_id, step, data_json, now.isoformat(), expires_at
        ))
        self.conn.commit()
        
        logger.debug(f"📝 Created session {session_id} for user {user_id}")
        
        return session_id
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Получить сессию"""
        query = "SELECT * FROM sessions WHERE session_id = ?"
        self.cursor.execute(query, (session_id,))
        row = self.cursor.fetchone()
        
        if row:
            session = dict(row)
            # Проверяем не истекла ли сессия
            expires_at = datetime.fromisoformat(session["expires_at"])
            if expires_at < datetime.now():
                self.delete_session(session_id)
                return None
            
            # Парсим данные
            if session["data"]:
                session["data"] = json.loads(session["data"])
            else:
                session["data"] = {}
            
            return session
        
        return None
    
    def update_session(self, session_id: str, step: str = None, data: Dict = None):
        """Обновить сессию"""
        updates = []
        values = []
        
        if step:
            updates.append("step = ?")
            values.append(step)
        
        if data is not None:
            data_json = json.dumps(data)
            updates.append("data = ?")
            values.append(data_json)
        
        if not updates:
            return False
        
        values.append(session_id)
        
        query = f"UPDATE sessions SET {', '.join(updates)} WHERE session_id = ?"
        self.cursor.execute(query, values)
        self.conn.commit()
        
        return self.cursor.rowcount > 0
    
    def delete_session(self, session_id: str):
        """Удалить сессию"""
        query = "DELETE FROM sessions WHERE session_id = ?"
        self.cursor.execute(query, (session_id,))
        self.conn.commit()
        
        logger.debug(f"🗑️ Deleted session {session_id}")
        
        return self.cursor.rowcount > 0
    
    def cleanup_expired_sessions(self):
        """Очистить истекшие сессии"""
        now = datetime.now().isoformat()
        query = "DELETE FROM sessions WHERE expires_at < ?"
        self.cursor.execute(query, (now,))
        deleted = self.cursor.rowcount
        self.conn.commit()
        
        if deleted:
            logger.info(f"🗑️ Cleaned up {deleted} expired sessions")
        
        return deleted
    
    # ------------------- Методы фильтров -------------------
    def add_user_filter(self, user_id: int, filter_name: str, jql: str, 
                       check_interval: int = 5) -> bool:
        """Добавить фильтр для пользователя"""
        now = datetime.now().isoformat()
        
        try:
            query = """
            INSERT INTO user_filters 
            (user_id, filter_name, jql, check_interval, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """
            self.cursor.execute(query, (
                user_id, filter_name, jql, check_interval, now, now
            ))
            self.conn.commit()
            
            logger.info(f"🔍 Added filter '{filter_name}' for user {user_id}")
            return True
        except sqlite3.IntegrityError:
            # Фильтр с таким именем уже существует
            logger.warning(f"Filter '{filter_name}' already exists for user {user_id}")
            return False
    
    def get_user_filters(self, user_id: int, active_only: bool = True) -> List[Dict[str, Any]]:
        """Получить фильтры пользователя"""
        if active_only:
            query = """
            SELECT * FROM user_filters 
            WHERE user_id = ? AND is_active = 1
            ORDER BY created_at DESC
            """
        else:
            query = """
            SELECT * FROM user_filters 
            WHERE user_id = ?
            ORDER BY created_at DESC
            """
        
        self.cursor.execute(query, (user_id,))
        rows = self.cursor.fetchall()
        
        filters = [dict(row) for row in rows]
        logger.debug(f"🔍 Found {len(filters)} filters for user {user_id}")
        
        return filters
    
    def delete_user_filter(self, user_id: int, filter_name: str) -> bool:
        """Удалить фильтр пользователя"""
        query = """
        DELETE FROM user_filters 
        WHERE user_id = ? AND filter_name = ?
        """
        self.cursor.execute(query, (user_id, filter_name))
        self.conn.commit()
        
        deleted = self.cursor.rowcount > 0
        
        if deleted:
            logger.info(f"🗑️ Deleted filter '{filter_name}' for user {user_id}")
        
        return deleted
    
    def toggle_filter_active(self, user_id: int, filter_name: str, is_active: bool) -> bool:
        """Включить/выключить фильтр"""
        now = datetime.now().isoformat()
        query = """
        UPDATE user_filters 
        SET is_active = ?, updated_at = ?
        WHERE user_id = ? AND filter_name = ?
        """
        self.cursor.execute(query, (1 if is_active else 0, now, user_id, filter_name))
        self.conn.commit()
        
        updated = self.cursor.rowcount > 0
        
        if updated:
            status = "enabled" if is_active else "disabled"
            logger.info(f"🔧 Filter '{filter_name}' {status} for user {user_id}")
        
        return updated
    
    def update_filter_interval(self, user_id: int, filter_name: str, interval: int) -> bool:
        """Изменить интервал проверки фильтра"""
        now = datetime.now().isoformat()
        query = """
        UPDATE user_filters 
        SET check_interval = ?, updated_at = ?
        WHERE user_id = ? AND filter_name = ?
        """
        self.cursor.execute(query, (interval, now, user_id, filter_name))
        self.conn.commit()
        
        updated = self.cursor.rowcount > 0
        
        if updated:
            logger.info(f"⏱️ Filter '{filter_name}' interval set to {interval} minutes for user {user_id}")
        
        return updated
    
    def get_filter(self, user_id: int, filter_name: str) -> Optional[Dict[str, Any]]:
        """Получить конкретный фильтр"""
        query = """
        SELECT * FROM user_filters 
        WHERE user_id = ? AND filter_name = ?
        """
        self.cursor.execute(query, (user_id, filter_name))
        row = self.cursor.fetchone()
        
        return dict(row) if row else None
    
    # ------------------- Методы истории задач -------------------
    def save_issue_state(self, user_id: int, filter_name: str, issue_key: str, 
                        issue_data: Dict, issue_hash: str) -> bool:
        """Сохранить состояние задачи"""
        now = datetime.now().isoformat()
        issue_data_json = json.dumps(issue_data)
        
        query = """
        INSERT INTO issue_history 
        (user_id, filter_name, issue_key, issue_data, issue_hash, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """
        
        try:
            self.cursor.execute(query, (
                user_id, filter_name, issue_key, issue_data_json, issue_hash, now
            ))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"❌ Error saving issue state: {e}")
            return False
    
    def get_last_issue_state(self, user_id: int, filter_name: str, issue_key: str) -> Optional[Dict]:
        """Получить последнее сохраненное состояние задачи"""
        query = """
        SELECT issue_data, issue_hash FROM issue_history 
        WHERE user_id = ? AND filter_name = ? AND issue_key = ?
        ORDER BY created_at DESC LIMIT 1
        """
        self.cursor.execute(query, (user_id, filter_name, issue_key))
        row = self.cursor.fetchone()
        
        if row:
            issue_data = json.loads(row["issue_data"])
            issue_hash = row["issue_hash"]
            return {"issue_data": issue_data, "issue_hash": issue_hash}
        
        return None
    
    def cleanup_old_issue_history(self, days: int = 30):
        """Очистить старую историю задач"""
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        query = "DELETE FROM issue_history WHERE created_at < ?"
        self.cursor.execute(query, (cutoff,))
        deleted = self.cursor.rowcount
        self.conn.commit()
        
        if deleted:
            logger.info(f"🗑️ Cleaned up {deleted} old issue history records (older than {days} days)")
        
        return deleted
    
    # ------------------- Методы обнаружения изменений -------------------
    def _calculate_issue_hash(self, issue_data: Dict[str, Any]) -> str:
        """Вычислить хэш состояния задачи"""
        # Создаем упрощенное представление задачи для сравнения
        fields = issue_data.get("fields", {})
        
        # Используем безопасные цепочки .get() с пустыми словарями по умолчанию
        issue_simplified = {
            "key": issue_data.get("key"),
            "summary": fields.get("summary"),
            "status": fields.get("status", {}).get("name") if fields.get("status") else None,
            "priority": fields.get("priority", {}).get("name") if fields.get("priority") else None,
            "assignee": fields.get("assignee", {}).get("displayName") if fields.get("assignee") else None,
            "updated": fields.get("updated"),
            "comment_count": len(fields.get("comment", {}).get("comments", [])),
            "resolution": fields.get("resolution", {}).get("name") if fields.get("resolution") else None
        }
        
        # Преобразуем в строкю и вычисляем хэш
        issue_str = json.dumps(issue_simplified, sort_keys=True)
        return hashlib.md5(issue_str.encode()).hexdigest()
    
    def _calculate_notification_hash(self, issue: Dict[str, Any], change_type: str) -> str:
        """Вычислить хэш уведомления"""
        # Создаем данные для хэширования
        notification_data = {
            "issue_key": issue.get("key"),
            "change_type": change_type,
            "timestamp": datetime.now().strftime("%Y%m%d%H%M")
        }
        
        # Преобразуем в строку и вычисляем хэш
        data_str = json.dumps(notification_data, sort_keys=True)
        return hashlib.md5(data_str.encode()).hexdigest()
    
    def check_and_update_issue(self, user_id: int, filter_name: str, 
                               issue: Dict[str, Any]) -> Dict[str, Any]:
        """
        Проверить изменения в задаче и обновить историю
        Возвращает информацию об изменениях
        """
        issue_key = issue.get("key")
        if not issue_key:
            return {"has_changes": False}
        
        # Вычисляем хэш текущего состояния
        current_hash = self._calculate_issue_hash(issue)
        
        # Получаем последнее сохраненное состояние
        last_state = self.get_last_issue_state(user_id, filter_name, issue_key)
        
        if not last_state:
            # Задача новая
            self.save_issue_state(user_id, filter_name, issue_key, issue, current_hash)
            return {
                "has_changes": True,
                "change_type": "new",
                "issue_key": issue_key,
                "is_new": True
            }
        else:
            # Сравниваем хэши
            if last_state["issue_hash"] != current_hash:
                # Обнаружены изменения
                self.save_issue_state(user_id, filter_name, issue_key, issue, current_hash)
                return {
                    "has_changes": True,
                    "change_type": "updated",
                    "issue_key": issue_key,
                    "is_new": False,
                    "previous_hash": last_state["issue_hash"],
                    "current_hash": current_hash
                }
            else:
                # Изменений нет
                return {"has_changes": False}
    
    def was_notification_sent(self, user_id: int, filter_name: str, 
                             issue_key: str, notification_hash: str) -> bool:
        """Проверить, было ли уже отправлено такое уведомление"""
        query = """
        SELECT COUNT(*) FROM notifications 
        WHERE user_id = ? AND filter_name = ? AND issue_key = ? 
        AND notification_hash = ?
        """
        self.cursor.execute(query, (user_id, filter_name, issue_key, notification_hash))
        count = self.cursor.fetchone()[0]
        return count > 0
    
    # ------------------- Методы уведомлений -------------------
    def record_notification(self, user_id: int, filter_name: str, issue_key: str,
                          notification_hash: str, change_type: str, 
                          details: Dict[str, Any] = None) -> bool:
        """Записать уведомление в базу (обновленная версия)"""
        if not details:
            details = {}
        
        # Преобразуем details в JSON
        details_json = json.dumps(details)
        
        # Получаем message_id из details, если есть
        message_id = details.get('message_id')
        
        query = """
        INSERT INTO notifications 
        (user_id, filter_name, issue_key, notification_hash, 
         change_type, details, message_id, is_reminder, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        try:
            self.cursor.execute(query, (
                user_id,
                filter_name,
                issue_key,
                notification_hash,
                change_type,
                details_json,
                message_id,
                details.get('is_reminder', 0),
                datetime.now().isoformat()
            ))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"❌ Error recording notification: {e}")
            return False
    
    def get_user_notifications(self, user_id: int, limit: int = 50) -> List[Dict[str, Any]]:
        """Получить уведомления пользователя"""
        query = """
        SELECT * FROM notifications 
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ?
        """
        self.cursor.execute(query, (user_id, limit))
        rows = self.cursor.fetchall()
        
        notifications = []
        for row in rows:
            notif = dict(row)
            if notif.get("details"):
                notif["details"] = json.loads(notif["details"])
            notifications.append(notif)
        
        return notifications
    
    def get_notifications_with_blockers(self, user_id: int, limit: int = 50) -> List[Dict[str, Any]]:
        """Получить уведомления пользователя с информацией о блокировках"""
        query = """
        SELECT * FROM notifications 
        WHERE user_id = ? 
        AND details LIKE '%blockers%'
        ORDER BY created_at DESC
        LIMIT ?
        """
        self.cursor.execute(query, (user_id, limit))
        rows = self.cursor.fetchall()
        
        notifications = []
        for row in rows:
            notif = dict(row)
            if notif.get("details"):
                notif["details"] = json.loads(notif["details"])
            notifications.append(notif)
        
        return notifications
    
    def get_notifications_by_issue(self, user_id: int, issue_key: str) -> List[Dict[str, Any]]:
        """Получить все уведомления по задаче"""
        query = """
        SELECT * FROM notifications 
        WHERE user_id = ? AND issue_key = ?
        ORDER BY created_at DESC
        """
        self.cursor.execute(query, (user_id, issue_key))
        rows = self.cursor.fetchall()
        
        notifications = []
        for row in rows:
            notif = dict(row)
            if notif.get("details"):
                notif["details"] = json.loads(notif["details"])
            notifications.append(notif)
        
        return notifications
    
    # ------------------- Методы для упоминаний -------------------
    def save_mention(self, user_id: int, issue_key: str, comment_id: str = None, 
                     mentioned_by: str = None, mention_text: str = None, 
                     mention_type: str = None) -> bool:
        """Сохранить упоминание пользователя"""
        try:
            now = datetime.now().isoformat()
            
            query = """
            INSERT OR IGNORE INTO user_mentions 
            (user_id, issue_key, comment_id, mentioned_by, mention_text, mention_type, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """
            
            self.cursor.execute(query, (
                user_id, issue_key, comment_id, mentioned_by, mention_text, mention_type, now
            ))
            self.conn.commit()
            
            saved = self.cursor.rowcount > 0
            if saved:
                logger.info(f"💬 Saved mention for user {user_id} in {issue_key}")
            
            return saved
        except Exception as e:
            logger.error(f"Error saving mention: {e}")
            return False
    
    def get_unnotified_mentions(self, user_id: int) -> List[Dict[str, Any]]:
        """Получить непрочитанные упоминания пользователя"""
        query = """
        SELECT * FROM user_mentions 
        WHERE user_id = ? AND notification_sent = 0
        ORDER BY created_at DESC
        """
        
        self.cursor.execute(query, (user_id,))
        rows = self.cursor.fetchall()
        
        mentions = [dict(row) for row in rows]
        logger.debug(f"📨 Found {len(mentions)} unnotified mentions for user {user_id}")
        
        return mentions
    
    def mark_mentions_as_notified(self, user_id: int, issue_key: str = None) -> bool:
        """Пометить упоминания как отправленные"""
        try:
            if issue_key:
                query = """
                UPDATE user_mentions 
                SET notification_sent = 1 
                WHERE user_id = ? AND issue_key = ?
                """
                self.cursor.execute(query, (user_id, issue_key))
            else:
                query = """
                UPDATE user_mentions 
                SET notification_sent = 1 
                WHERE user_id = ?
                """
                self.cursor.execute(query, (user_id,))
            
            self.conn.commit()
            updated = self.cursor.rowcount > 0
            
            if updated:
                logger.info(f"✅ Marked mentions as notified for user {user_id}")
            
            return updated
        except Exception as e:
            logger.error(f"Error marking mentions as notified: {e}")
            return False
    
    def get_last_mention_check_time(self, user_id: int) -> Optional[str]:
        """Получить время последней проверки упоминаний"""
        query = """
        SELECT MAX(created_at) as last_check 
        FROM user_mentions 
        WHERE user_id = ?
        """
        
        self.cursor.execute(query, (user_id,))
        row = self.cursor.fetchone()
        
        return row["last_check"] if row and row["last_check"] else None
    
    def get_total_mentions(self, user_id: int) -> int:
        """Получить общее количество упоминаний пользователя"""
        query = """
        SELECT COUNT(*) FROM user_mentions 
        WHERE user_id = ?
        """
        
        self.cursor.execute(query, (user_id,))
        count = self.cursor.fetchone()[0]
        
        return count or 0
    
    # ------------------- Методы для системы напоминаний -------------------
    def should_send_reminder(self, user_id: int, filter_name: str, issue_key: str) -> Tuple[bool, Optional[int]]:
        """
        Проверяет, нужно ли отправлять напоминание о задаче.
        Возвращает (bool, message_id)
        """
        try:
            # ПЕРВЫМ ДЕЛОМ проверяем, отключена ли задача
            if self.is_task_muted(user_id, issue_key, filter_name):
                logger.info(f"🔇 Task {issue_key} is muted for filter {filter_name}, skipping reminder check")
                return False, None
            
            # Импортируем здесь внутри функции, чтобы избежать циклических импортов
            from .utils import should_send_reminder_check
            
            # Получаем интервал из конфигурации
            from .config import REMINDER_INTERVAL_MINUTES
            
            # Проверяем, подтвердил ли пользователь задачу
            query = """
            SELECT id, message_id, created_at FROM notifications 
            WHERE user_id = ? AND filter_name = ? AND issue_key = ? 
            AND (user_reaction IS NULL OR user_reaction = '') 
            AND is_reminder = 0
            ORDER BY created_at DESC LIMIT 1
            """
            self.cursor.execute(query, (user_id, filter_name, issue_key))
            row = self.cursor.fetchone()
            
            if not row:
                return False, None
            
            notif_id, message_id, created_at = row
            
            # Проверяем, прошло ли REMINDER_INTERVAL_MINUTES с момента последнего уведомления
            now = datetime.now()
            notification_time = datetime.fromisoformat(created_at)
            time_diff = now - notification_time
            
            # Интервал из конфигурации
            reminder_interval = timedelta(minutes=REMINDER_INTERVAL_MINUTES)
            
            if time_diff > reminder_interval:
                # Проверяем, не ночное ли время сейчас
                if should_send_reminder_check():
                    logger.info(f"✅ Should send reminder for {issue_key} to user {user_id}")
                    return True, message_id
                else:
                    logger.info(f"🌙 Пропускаем напоминание из-за ночного времени (задача {issue_key})")
                    return False, None
            
            logger.debug(f"⏰ Not yet time for reminder for {issue_key}: {time_diff.seconds//60} min < {REMINDER_INTERVAL_MINUTES} min")
            return False, None
            
        except Exception as e:
            logger.error(f"❌ Error in should_send_reminder: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False, None
    
    def get_pending_notifications(self, user_id: int) -> List[Dict[str, Any]]:
        """
        Получить список неподтвержденных уведомлений пользователя
        """
        query = """
        SELECT 
            n.issue_key,
            n.filter_name,
            n.created_at as last_notification,
            COUNT(*) as notification_count,
            MAX(n.created_at) as latest_notification
        FROM notifications n
        WHERE n.user_id = ? 
            AND (n.user_reaction IS NULL OR n.user_reaction = '')
            AND n.is_reminder = 0
        GROUP BY n.issue_key, n.filter_name
        ORDER BY latest_notification DESC
        """
        self.cursor.execute(query, (user_id,))
        rows = self.cursor.fetchall()
        
        pending = []
        for row in rows:
            pending.append({
                'issue_key': row[0],
                'filter_name': row[1],
                'last_notification': row[2],
                'notification_count': row[3],
                'latest_notification': row[4]
            })
        
        return pending
    
    def get_last_notification_info(self, user_id: int, filter_name: str, issue_key: str) -> Optional[Dict]:
        """
        Получить информацию о последнем уведомлении для задачи
        """
        try:
            query = """
            SELECT 
                notification_hash,
                change_type,
                details
            FROM notifications 
            WHERE user_id = ? AND filter_name = ? AND issue_key = ? 
            AND is_reminder = 0
            ORDER BY created_at DESC LIMIT 1
            """
            self.cursor.execute(query, (user_id, filter_name, issue_key))
            row = self.cursor.fetchone()
            
            if not row:
                return None
            
            notification_hash, change_type, details_json = row
            
            # Парсим JSON с деталями
            details = json.loads(details_json) if details_json else {}
            
            return {
                "issue_key": issue_key,
                "notification_hash": notification_hash,
                "change_type": change_type,
                "issue": {
                    "key": issue_key,
                    "fields": {
                        "summary": details.get("summary", "Без названия"),
                        "status": {"name": details.get("status", "Неизвестно")},
                        "priority": {"name": details.get("priority", "Не указан")},
                        "assignee": {"displayName": details.get("assignee", "Не назначен")},
                        "issuelinks": []
                    }
                },
                "is_new": change_type == "new",
                "blockers": details.get("blockers", []),
                "blockers_count": details.get("blockers_count", 0),
                "active_blockers": details.get("active_blockers", 0)
            }
            
        except Exception as e:
            logger.error(f"❌ Error in get_last_notification_info: {e}")
            return None
    
    def record_user_reaction(self, user_id: int, issue_key: str, notification_hash: str) -> bool:
        """
        Записать реакцию пользователя на уведомление
        """
        query = """
        UPDATE notifications 
        SET user_reaction = 'acknowledged',
            reaction_time = ?
        WHERE user_id = ? AND issue_key = ? AND notification_hash = ?
        """
        self.cursor.execute(query, (
            datetime.now().isoformat(),
            user_id,
            issue_key,
            notification_hash
        ))
        self.conn.commit()
        
        # Также отмечаем все остальные уведомления по этой задаче как подтвержденные
        query_all = """
        UPDATE notifications 
        SET user_reaction = 'acknowledged'
        WHERE user_id = ? AND issue_key = ? 
        AND (user_reaction IS NULL OR user_reaction = '')
        """
        self.cursor.execute(query_all, (user_id, issue_key))
        self.conn.commit()
        
        logger.info(f"✅ User {user_id} acknowledged notification for {issue_key}")
        
        return self.cursor.rowcount > 0
    
    def has_user_reacted(self, user_id: int, issue_key: str, notification_hash: str) -> bool:
        """
        Проверить, отреагировал ли пользователь на уведомление
        """
        query = """
        SELECT COUNT(*) FROM notifications 
        WHERE user_id = ? AND issue_key = ? AND notification_hash = ?
        AND user_reaction IS NOT NULL AND user_reaction != ''
        """
        self.cursor.execute(query, (user_id, issue_key, notification_hash))
        count = self.cursor.fetchone()[0]
        return count > 0
    
    def is_task_muted(self, user_id: int, issue_key: str, filter_name: str = None) -> bool:
        """
        Проверить, отключены ли уведомления для задачи.
        Если filter_name не указан, проверяем ВСЕ фильтры.
        """
        try:
            now = datetime.now().isoformat()
            
            if filter_name:
                # Проверяем конкретный фильтр
                query = """
                SELECT muted_until FROM muted_tasks 
                WHERE user_id = ? AND issue_key = ? AND filter_name = ?
                AND muted_until > ?
                """
                self.cursor.execute(query, (user_id, issue_key, filter_name, now))
            else:
                # Проверяем ВСЕ фильтры для этой задачи
                query = """
                SELECT muted_until FROM muted_tasks 
                WHERE user_id = ? AND issue_key = ?
                AND muted_until > ?
                LIMIT 1
                """
                self.cursor.execute(query, (user_id, issue_key, now))
            
            row = self.cursor.fetchone()
            
            if row:
                logger.info(f"🔇 Task {issue_key} is muted for user {user_id} until {row[0]}")
                return True
            else:
                logger.debug(f"🔔 Task {issue_key} is NOT muted for user {user_id}")
                return False
                
        except Exception as e:
            logger.error(f"❌ Error in is_task_muted: {e}")
            return False
    
    def mute_task_notifications(self, user_id: int, issue_key: str, filter_name: str, hours: int = 24) -> bool:
        """
        Временно отключить уведомления для задачи
        """
        # Сначала удаляем старые записи для этой задачи
        query_delete = """
        DELETE FROM muted_tasks 
        WHERE user_id = ? AND issue_key = ? AND filter_name = ?
        """
        self.cursor.execute(query_delete, (user_id, issue_key, filter_name))
        
        # Теперь добавляем новую запись
        muted_until = datetime.now() + timedelta(hours=hours)
        
        query = """
        INSERT INTO muted_tasks 
        (user_id, issue_key, filter_name, muted_until, created_at)
        VALUES (?, ?, ?, ?, ?)
        """
        self.cursor.execute(query, (
            user_id,
            issue_key,
            filter_name,
            muted_until.isoformat(),
            datetime.now().isoformat()
        ))
        self.conn.commit()
        
        logger.info(f"🔇 Muted notifications for {issue_key} (filter: {filter_name}) for {hours} hours (user {user_id})")
        
        return True
    
    def cleanup_expired_muted_tasks(self):
        """Очистить истекшие записи о временно отключенных задачах"""
        now = datetime.now().isoformat()
        query = "DELETE FROM muted_tasks WHERE muted_until < ?"
        self.cursor.execute(query, (now,))
        deleted = self.cursor.rowcount
        self.conn.commit()
        
        if deleted:
            logger.info(f"🗑️ Cleaned up {deleted} expired muted tasks")
        
        return deleted
    
    # ------------------- Статистика -------------------
    def get_user_stats(self, user_id: int) -> Dict[str, Any]:
        """
        Получить статистику пользователя (обновленная версия)
        """
        stats = {
            'total_filters': 0,
            'active_filters': 0,
            'total_tracked': 0,
            'total_notifications': 0,
            'pending_notifications': 0,
            'blockers_count': 0,
            'active_blockers': 0,
            'mentions_count': 0
        }
        
        # Количество фильтров
        query_filters = """
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active
        FROM user_filters 
        WHERE user_id = ?
        """
        self.cursor.execute(query_filters, (user_id,))
        filters_row = self.cursor.fetchone()
        if filters_row:
            stats['total_filters'] = filters_row[0] or 0
            stats['active_filters'] = filters_row[1] or 0
        
        # Количество отслеживаемых задач (уникальных issue_key)
        query_tracked = """
        SELECT COUNT(DISTINCT issue_key) 
        FROM notifications 
        WHERE user_id = ?
        """
        self.cursor.execute(query_tracked, (user_id,))
        tracked_row = self.cursor.fetchone()
        if tracked_row:
            stats['total_tracked'] = tracked_row[0] or 0
        
        # Общее количество уведомлений
        query_notifications = """
        SELECT COUNT(*) 
        FROM notifications 
        WHERE user_id = ?
        """
        self.cursor.execute(query_notifications, (user_id,))
        notif_row = self.cursor.fetchone()
        if notif_row:
            stats['total_notifications'] = notif_row[0] or 0
        
        # Количество неподтвержденных уведомлений
        query_pending = """
        SELECT COUNT(*) 
        FROM notifications 
        WHERE user_id = ? 
        AND (user_reaction IS NULL OR user_reaction = '')
        AND is_reminder = 0
        """
        self.cursor.execute(query_pending, (user_id,))
        pending_row = self.cursor.fetchone()
        if pending_row:
            stats['pending_notifications'] = pending_row[0] or 0
        
        # Статистика по блокировкам
        query_blockers = """
        SELECT 
            details
        FROM notifications 
        WHERE user_id = ? 
        AND details LIKE '%blockers%'
        """
        self.cursor.execute(query_blockers, (user_id,))
        blocker_rows = self.cursor.fetchall()
        
        total_blockers = 0
        active_blockers = 0
        
        for row in blocker_rows:
            details_json = row[0]
            if details_json:
                try:
                    details = json.loads(details_json)
                    total_blockers += details.get('blockers_count', 0)
                    active_blockers += details.get('active_blockers', 0)
                except:
                    pass
        
        stats['blockers_count'] = total_blockers
        stats['active_blockers'] = active_blockers
        
        # Статистика по упоминаниям
        query_mentions = """
        SELECT COUNT(*) FROM user_mentions 
        WHERE user_id = ?
        """
        self.cursor.execute(query_mentions, (user_id,))
        mentions_row = self.cursor.fetchone()
        if mentions_row:
            stats['mentions_count'] = mentions_row[0] or 0
        
        return stats
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Получить системную статистику"""
        stats = {
            'total_users': 0,
            'active_users': 0,
            'total_filters': 0,
            'active_filters': 0,
            'total_notifications': 0,
            'blockers_count': 0,
            'active_blockers': 0,
            'total_mentions': 0
        }
        
        # Общее количество пользователей
        query_total_users = "SELECT COUNT(*) FROM users"
        self.cursor.execute(query_total_users)
        stats['total_users'] = self.cursor.fetchone()[0] or 0
        
        # Активные пользователи (с настройками Jira)
        query_active_users = """
        SELECT COUNT(*) FROM users 
        WHERE is_active = 1 
        AND jira_user IS NOT NULL 
        AND jira_token IS NOT NULL
        """
        self.cursor.execute(query_active_users)
        stats['active_users'] = self.cursor.fetchone()[0] or 0
        
        # Все фильтры
        query_total_filters = "SELECT COUNT(*) FROM user_filters"
        self.cursor.execute(query_total_filters)
        stats['total_filters'] = self.cursor.fetchone()[0] or 0
        
        # Активные фильтры
        query_active_filters = """
        SELECT COUNT(*) FROM user_filters WHERE is_active = 1
        """
        self.cursor.execute(query_active_filters)
        stats['active_filters'] = self.cursor.fetchone()[0] or 0
        
        # Все уведомления
        query_total_notifications = "SELECT COUNT(*) FROM notifications"
        self.cursor.execute(query_total_notifications)
        stats['total_notifications'] = self.cursor.fetchone()[0] or 0
        
        # Статистика по блокировкам
        query_blockers = """
        SELECT details FROM notifications WHERE details LIKE '%blockers%'
        """
        self.cursor.execute(query_blockers)
        blocker_rows = self.cursor.fetchall()
        
        total_blockers = 0
        active_blockers = 0
        
        for row in blocker_rows:
            details_json = row[0]
            if details_json:
                try:
                    details = json.loads(details_json)
                    total_blockers += details.get('blockers_count', 0)
                    active_blockers += details.get('active_blockers', 0)
                except:
                    pass
        
        stats['blockers_count'] = total_blockers
        stats['active_blockers'] = active_blockers
        
        # Статистика по упоминаниям
        query_mentions = "SELECT COUNT(*) FROM user_mentions"
        self.cursor.execute(query_mentions)
        stats['total_mentions'] = self.cursor.fetchone()[0] or 0
        
        return stats
    
    # ------------------- Очистка данных -------------------
    def cleanup_old_data(self, days: int = 30):
        """Очистить старые данные (НЕ ВКЛЮЧАЕТ users и user_filters!)"""
        logger.info(f"🔄 Starting cleanup_old_data for days={days}")
        
        total_deleted = 0
        
        # Очищаем старые сессии
        sessions_deleted = self.cleanup_expired_sessions()
        total_deleted += sessions_deleted
        
        # Очищаем старую историю задач
        history_deleted = self.cleanup_old_issue_history(days)
        total_deleted += history_deleted
        
        # Очищаем истекшие записи о временно отключенных задачах
        muted_deleted = self.cleanup_expired_muted_tasks()
        total_deleted += muted_deleted
        
        # Очищаем старые упоминания
        mention_cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        query_mentions = "DELETE FROM user_mentions WHERE created_at < ?"
        self.cursor.execute(query_mentions, (mention_cutoff,))
        mentions_deleted = self.cursor.rowcount
        self.conn.commit()
        total_deleted += mentions_deleted
        
        if mentions_deleted:
            logger.info(f"🗑️ Cleaned up {mentions_deleted} old mentions (older than {days} days)")
        
        # Логируем количество записей в таблицах ПОСЛЕ очистки
        logger.info("📊 Database stats after cleanup:")
        tables = ['users', 'user_filters', 'notifications', 'issue_history', 'muted_tasks', 'sessions', 'user_mentions']
        for table in tables:
            try:
                self.cursor.execute(f"SELECT COUNT(*) as count FROM {table}")
                count = self.cursor.fetchone()['count']
                logger.info(f"  {table}: {count} records")
            except:
                logger.warning(f"  {table}: table doesn't exist")
        
        logger.info(f"✅ Total cleaned up {total_deleted} old records (older than {days} days)")
        return total_deleted
    
    # ------------------- Backup -------------------
    def backup_database(self, backup_path: str = None):
        """Создать резервную копию базы данных"""
        import shutil
        import os
        
        if backup_path is None:
            data_dir = os.path.dirname(self.db_path)
            backup_dir = os.path.join(data_dir, "backups")
            os.makedirs(backup_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = os.path.join(backup_dir, f"jira_bot_backup_{timestamp}.db")
        
        # Создаем копию базы данных
        shutil.copy2(self.db_path, backup_path)
        
        # Также копируем ключ шифрования если он рядом
        key_path = os.path.join(os.path.dirname(self.db_path), "encryption.key")
        if os.path.exists(key_path):
            backup_key_path = backup_path.replace(".db", ".key")
            shutil.copy2(key_path, backup_key_path)
        
        logger.info(f"📦 Database backed up to: {backup_path}")
        return backup_path
    
    # ------------------- Закрытие соединения -------------------
    def close(self):
        """Закрыть соединение с базой данных"""
        self.conn.close()
        logger.info("Database connection closed")

# Создаем глобальный экземпляр базы данных
# Передаем путь из переменной окружения если он есть
import os
from .config import ENCRYPTION_KEY, DATABASE_PATH

# Создаем экземпляр базы данных
db = Database(db_path=DATABASE_PATH, encryption_key=ENCRYPTION_KEY)