# watcher.py
import logging
import hashlib
import json
from typing import Optional, Dict, Any, List
from datetime import datetime
from .db import db
from .utils import should_send_reminder_check, get_msk_time

logger = logging.getLogger(__name__)

class SmartWatcher:
    def __init__(self):
        self.db = db
        logger.info("✅ SmartWatcher initialized with blocker tracking")
    
    def detect_changes(self, user_id: int, filter_name: str, 
                      issue: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Умное обнаружение изменений для конкретного пользователя.
        """
        try:
            # Проверяем, изменилась ли задача
            change_info = self.db.check_and_update_issue(user_id, filter_name, issue)
            
            if not change_info.get("has_changes"):
                logger.debug(f"ℹ️ No changes detected for issue {issue.get('key')}")
                return None
            
            # Вычисляем хеш уведомления
            notification_hash = self.db._calculate_notification_hash(
                issue, 
                change_info["change_type"]
            )
            
            if not notification_hash:
                logger.warning(f"⚠️ Could not calculate notification hash for {issue.get('key')}")
                return None
            
            # Проверяем, отправляли ли уже такое уведомление
            issue_key = change_info["issue_key"]
            if self.db.was_notification_sent(user_id, filter_name, issue_key, notification_hash):
                logger.info(f"📭 Notification already sent for {issue_key}")
                return None
            
            # Проверяем ночное время и логируем
            if not should_send_reminder_check():
                msk_time = get_msk_time()
                logger.info(f"🌙 Night time ({msk_time}), but sending initial notification for {issue_key}")
                # Изначальные уведомления отправляем даже ночью,
                # а вот напоминания уже будут откладываться
            
            # Возвращаем полную информацию для уведомления
            result = {
                "change_type": change_info["change_type"],
                "issue_key": issue_key,
                "notification_hash": notification_hash,
                "issue": issue,
                "is_new": change_info.get("is_new", False),
                "user_id": user_id,
                "filter_name": filter_name
            }
            
            logger.info(f"📨 Change detected for user {user_id}: {issue_key} ({change_info['change_type']})")
            return result
            
        except Exception as e:
            logger.error(f"❌ Error in detect_changes for user {user_id}, issue {issue.get('key', 'unknown')}: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return None
    
    async def detect_changes_with_blockers(self, user_id: int, filter_name: str, 
                                         issue: Dict[str, Any], client) -> Optional[Dict[str, Any]]:
        """
        Обнаружение изменений с анализом блокирующих задач
        """
        try:
            # Основное обнаружение изменений
            change_info = self.db.check_and_update_issue(user_id, filter_name, issue)
            
            if not change_info.get("has_changes"):
                return None
            
            # Анализируем блокирующие задачи
            blocking_info = await self.analyze_blockers(user_id, filter_name, issue, client)
            
            # Вычисляем хэш уведомления с учетом блокирующих задач
            notification_hash = self._calculate_notification_hash_with_blockers(
                issue, 
                change_info["change_type"],
                blocking_info
            )
            
            if not notification_hash:
                return None
            
            # Проверяем, отправляли ли уже такое уведомление
            issue_key = change_info["issue_key"]
            if self.db.was_notification_sent(user_id, filter_name, issue_key, notification_hash):
                return None
            
            # Возвращаем расширенную информацию
            result = {
                "change_type": change_info["change_type"],
                "issue_key": issue_key,
                "notification_hash": notification_hash,
                "issue": issue,
                "is_new": change_info.get("is_new", False),
                "user_id": user_id,
                "filter_name": filter_name,
                "blockers": blocking_info
            }
            
            logger.info(f"📨 Change detected with blockers for user {user_id}: {issue_key}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Error in detect_changes_with_blockers: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return None
    
    async def analyze_blockers(self, user_id: int, filter_name: str, 
                             issue: Dict[str, Any], client) -> List[Dict[str, Any]]:
        """
        Анализ блокирующих задач для конкретной задачи
        """
        try:
            issue_key = issue.get("key")
            logger.info(f"🔍 Analyzing blockers for {issue_key}")
            
            blockers = []
            
            # Получаем связи задачи
            issue_links = issue.get("fields", {}).get("issuelinks", [])
            
            if not issue_links:
                logger.info(f"📭 No issue links found for {issue_key}")
                return []
            
            # Анализируем все связи
            for link in issue_links:
                link_type = link.get("type", {})
                inward_issue = link.get("inwardIssue")
                outward_issue = link.get("outwardIssue")
                
                # Проверяем блокирующие связи (inward - блокирует текущую задачу)
                if inward_issue and link_type.get("inward", "") in ["блокируется", "блокируется посредством", "blocks", "is blocked by"]:
                    blocker_info = await self._get_blocker_info(client, inward_issue, "inward")
                    if blocker_info:
                        blockers.append(blocker_info)
                
                # Проверяем блокируемые связи (outward - текущая задача блокирует другие)
                if outward_issue and link_type.get("outward", "") in ["блокирует", "блокирует посредством", "blocks", "is blocked by"]:
                    blocker_info = await self._get_blocker_info(client, outward_issue, "outward")
                    if blocker_info:
                        blockers.append(blocker_info)
            
            # УБИРАЕМ ДУБЛИКАТЫ на основе ключей задач
            unique_blockers = []
            seen_keys = set()
            
            for blocker in blockers:
                blocker_key = blocker.get("key")
                if blocker_key and blocker_key not in seen_keys:
                    seen_keys.add(blocker_key)
                    unique_blockers.append(blocker)
                elif not blocker_key:
                    # Если нет ключа, все равно добавляем
                    unique_blockers.append(blocker)
            
            logger.info(f"📊 Found {len(unique_blockers)} unique blockers out of {len(blockers)} total for {issue_key}")
            return unique_blockers
            
        except Exception as e:
            logger.error(f"❌ Error analyzing blockers for {issue.get('key', 'unknown')}: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return []
    
    async def _get_blocker_info(self, client, blocker_issue: Dict[str, Any], direction: str) -> Optional[Dict[str, Any]]:
        """
        Получить информацию о блокирующей задаче (улучшенная версия)
        """
        try:
            issue_key = blocker_issue.get("key")
            if not issue_key:
                return None
            
            # Получаем полную информацию о блокирующей задаче
            issue_data = client.get_issue(issue_key)
            if not issue_data:
                return None
            
            fields = issue_data.get("fields", {})
            
            # Определяем тип блокировки
            resolution = fields.get("resolution")
            is_resolved = resolution is not None
            
            return {
                "key": issue_key,
                "summary": fields.get("summary", "Без названия"),
                "status": fields.get("status", {}).get("name", "Неизвестно"),
                "assignee": fields.get("assignee", {}).get("displayName", "Не назначен"),
                "is_resolved": is_resolved,
                "resolution": resolution.get("name") if resolution else None,
                "priority": fields.get("priority", {}).get("name", "Не указан"),
                "updated": fields.get("updated"),
                "url": f"{client.base_url}/browse/{issue_key}",
                "direction": direction  # Добавляем направление связи
            }
            
        except Exception as e:
            logger.error(f"❌ Error getting blocker info for {blocker_issue.get('key', 'unknown')}: {e}")
            return None
    
    def _calculate_notification_hash_with_blockers(self, issue: Dict[str, Any], 
                                                 change_type: str, 
                                                 blockers: List[Dict[str, Any]]) -> str:
        """
        Вычислить хэш уведомления с учетом блокирующих задач
        """
        # Базовые данные
        base_data = {
            "issue_key": issue.get("key"),
            "change_type": change_type,
            "timestamp": datetime.now().strftime("%Y%m%d%H%M")
        }
        
        # Добавляем информацию о блокирующих задачах
        blockers_data = []
        for blocker in blockers:
            blockers_data.append({
                "key": blocker.get("key"),
                "status": blocker.get("status"),
                "is_resolved": blocker.get("is_resolved"),
                "assignee": blocker.get("assignee"),
                "updated": blocker.get("updated")
            })
        
        base_data["blockers"] = blockers_data
        
        # Преобразуем в строку и вычисляем хэш
        data_str = json.dumps(base_data, sort_keys=True)
        return hashlib.md5(data_str.encode()).hexdigest()

# Глобальный экземпляр
smart_watcher = SmartWatcher()