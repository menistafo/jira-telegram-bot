# utils.py
import pytz
from datetime import datetime, time, timedelta
import logging

logger = logging.getLogger(__name__)

def is_night_time_msk(now_utc: datetime = None) -> bool:
    """
    Проверяет, сейчас ночное время по МСК?
    Ночное время: с 22:00 до 09:00 по МСК
    """
    try:
        if now_utc is None:
            now_utc = datetime.utcnow()
        
        # Определяем часовой пояс МСК
        msk_tz = pytz.timezone('Europe/Moscow')
        
        # Конвертируем UTC в МСК
        now_msk = now_utc.replace(tzinfo=pytz.utc).astimezone(msk_tz)
        
        # Получаем час в МСК
        msk_hour = now_msk.hour
        
        # Ночное время: с 22:00 до 09:00
        if msk_hour >= 22 or msk_hour < 9:
            logger.debug(f"🌙 Ночное время по МСК: {now_msk.strftime('%H:%M')}")
            return True
        
        logger.debug(f"☀️ Дневное время по МСК: {now_msk.strftime('%H:%M')}")
        return False
        
    except Exception as e:
        logger.error(f"❌ Ошибка при определении времени МСК: {e}")
        # В случае ошибки считаем, что дневное время
        return False

def get_msk_time() -> str:
    """Получить текущее время по МСК в формате строки"""
    try:
        msk_tz = pytz.timezone('Europe/Moscow')
        now_msk = datetime.now(pytz.utc).astimezone(msk_tz)
        return now_msk.strftime("%Y-%m-%d %H:%M:%S (MSK)")
    except:
        return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S (UTC)")

def should_send_reminder_check() -> bool:
    """
    Проверяет, можно ли отправлять напоминание сейчас.
    Учитывает ночное время по МСК.
    """
    from .config import NIGHT_MODE_ENABLED
    
    if not NIGHT_MODE_ENABLED:
        return True
    
    return not is_night_time_msk()

def format_time_until_morning() -> str:
    """
    Возвращает строку с временем до утра (09:00 МСК)
    """
    try:
        msk_tz = pytz.timezone('Europe/Moscow')
        now_utc = datetime.now(pytz.utc)
        now_msk = now_utc.astimezone(msk_tz)
        
        # Рассчитываем время 09:00 следующего дня по МСК
        morning_time = now_msk.replace(hour=9, minute=0, second=0, microsecond=0)
        
        # Если уже утро, но не прошло 09:00 сегодня
        if now_msk.hour < 9:
            # Утро еще не наступило сегодня
            morning_time = now_msk.replace(hour=9, minute=0, second=0, microsecond=0)
        else:
            # Уже позже 09:00, значит ждем до завтра
            morning_time = (now_msk + timedelta(days=1)).replace(hour=9, minute=0, second=0, microsecond=0)
        
        # Рассчитываем разницу
        time_diff = morning_time - now_msk
        
        # Форматируем
        hours = time_diff.seconds // 3600
        minutes = (time_diff.seconds % 3600) // 60
        
        return f"{hours}ч {minutes}м"
        
    except Exception as e:
        logger.error(f"❌ Ошибка расчета времени до утра: {e}")
        return "неизвестно"

def get_next_reminder_time(last_notification_time: datetime) -> str:
    """
    Возвращает время следующего напоминания в формате строки
    """
    try:
        # Добавляем 30 минут к времени последнего уведомления
        next_time = last_notification_time + timedelta(minutes=30)
        
        # Конвертируем в МСК
        msk_tz = pytz.timezone('Europe/Moscow')
        next_time_msk = next_time.replace(tzinfo=pytz.utc).astimezone(msk_tz)
        
        return next_time_msk.strftime("%H:%M (МСК)")
    except Exception as e:
        logger.error(f"❌ Ошибка расчета времени следующего напоминания: {e}")
        return "неизвестно"