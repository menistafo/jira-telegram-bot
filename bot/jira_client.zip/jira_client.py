# jira_client.py
import requests
import logging
import asyncio
import time
import urllib3
from datetime import datetime
from typing import List, Dict, Optional, Any
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Отключаем предупреждения о SSL
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

class JiraClient:
    def __init__(self, base_url: str = None, username: str = None, token: str = None):
        from .config import JIRA_BASE_URL
        
        self.base_url = (base_url or JIRA_BASE_URL).rstrip('/')
        self.username = username
        self.token = token
        
        # Формируем заголовки с Bearer Token
        self.headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.token}" if self.token else "",
            "Content-Type": "application/json"
        }
        
        # Создаем сессию с ретраями
        self.session = self._create_session()
        
        logger.debug(f"JiraClient created for {username}")
    
    def _create_session(self):
        """Создать сессию с настройками ретраев"""
        session = requests.Session()
        
        # Более агрессивные настройки ретраев
        retry_strategy = Retry(
            total=5,  # Увеличиваем количество попыток
            backoff_factor=2,  # Увеличиваем задержку между попытками
            status_forcelist=[429, 500, 502, 503, 504, 520, 521, 522, 523, 524],
            allowed_methods=["GET", "POST", "PUT", "DELETE"]
        )
        
        adapter = HTTPAdapter(
            max_retries=retry_strategy, 
            pool_connections=20, 
            pool_maxsize=20
        )
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        return session
    
    def _make_request(self, endpoint: str, method: str = "GET", params: Dict = None, 
                     data: Dict = None, timeout: int = 30) -> requests.Response:
        """Универсальный метод для выполнения запросов"""
        url = f"{self.base_url}{endpoint}"
        
        max_retries = 3
        retry_delay = 2  # секунды
        
        for attempt in range(max_retries):
            try:
                logger.debug(f"Making {method} request to: {url} (attempt {attempt + 1}/{max_retries})")
                
                response = self.session.request(
                    method=method,
                    url=url,
                    headers=self.headers,
                    params=params,
                    json=data,
                    timeout=timeout,
                    verify=False  # Отключить проверку SSL
                )
                
                logger.debug(f"Response status: {response.status_code}")
                
                # Проверяем статус ответа
                if response.status_code == 429:  # Too Many Requests
                    retry_after = int(response.headers.get('Retry-After', 60))
                    logger.warning(f"Rate limited. Waiting {retry_after} seconds...")
                    time.sleep(retry_after)
                    continue
                
                return response
                
            except requests.exceptions.ConnectionError as e:
                logger.warning(f"Connection error (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    sleep_time = retry_delay * (attempt + 1)
                    logger.info(f"Waiting {sleep_time} seconds before retry...")
                    time.sleep(sleep_time)
                else:
                    logger.error(f"Max retries exceeded for {url}")
                    raise
                    
            except requests.exceptions.Timeout as e:
                logger.warning(f"Timeout error (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))
                else:
                    raise
                    
            except Exception as e:
                logger.error(f"Request failed: {e}")
                raise
        
        # Это не должно случиться, но на всякий случай
        raise requests.exceptions.RequestException(f"Failed after {max_retries} attempts")
    
    def test_connection(self) -> bool:
        """Проверить подключение к Jira"""
        try:
            # Простой запрос для проверки аутентификации
            response = self._make_request("/rest/api/2/myself", method="GET")
            
            if response.status_code == 200:
                data = response.json()
                logger.info(f"✅ Jira connection successful for user: {data.get('displayName', 'Unknown')}")
                return True
            else:
                logger.error(f"❌ Jira connection failed: {response.status_code} - {response.text[:200]}")
                return False
                
        except Exception as e:
            logger.error(f"❌ Jira connection error: {e}")
            return False
    
    def search(self, jql: str, max_results: int = 50) -> List[Dict[str, Any]]:
        """Поиск задач по JQL"""
        try:
            params = {
                "jql": jql,
                "maxResults": max_results,
                "fields": "id,key,summary,assignee,status,priority,updated,issuelinks,comment,reporter"
            }
            
            response = self._make_request("/rest/api/2/search", params=params)
            
            if response.status_code == 200:
                data = response.json()
                issues = data.get("issues", [])
                logger.info(f"✅ Found {len(issues)} issues for JQL: {jql[:50]}...")
                return issues
            else:
                logger.error(f"❌ Search failed: {response.status_code} - {response.text[:200]}")
                return []
                
        except Exception as e:
            logger.error(f"❌ Search error: {e}")
            return []
    
    def get_issue(self, issue_key: str) -> Optional[Dict[str, Any]]:
        """Получить информацию о задаче"""
        try:
            params = {
                "fields": "id,key,summary,assignee,status,priority,updated,issuelinks,comment,reporter,description,creator"
            }
            
            response = self._make_request(f"/rest/api/2/issue/{issue_key}", params=params)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"❌ Get issue failed: {response.status_code} - {response.text[:200]}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Get issue error: {e}")
            return None
    
    def get_issue_with_comments(self, issue_key: str) -> Optional[Dict[str, Any]]:
        """Получить задачу с комментариями"""
        try:
            params = {
                "fields": "id,key,summary,assignee,status,priority,updated,issuelinks,comment,reporter,description,creator",
                "expand": "comment"
            }
            
            response = self._make_request(f"/rest/api/2/issue/{issue_key}", params=params)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"❌ Get issue with comments failed: {response.status_code} - {response.text[:200]}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Get issue with comments error: {e}")
            return None
    
    def get_comments(self, issue_key: str) -> List[Dict[str, Any]]:
        """Получить комментарии задачи"""
        try:
            response = self._make_request(f"/rest/api/2/issue/{issue_key}/comment")
            
            if response.status_code == 200:
                data = response.json()
                return data.get("comments", [])
            else:
                logger.error(f"❌ Get comments failed: {response.status_code} - {response.text[:200]}")
                return []
                
        except Exception as e:
            logger.error(f"❌ Get comments error: {e}")
            return []
    
    def is_resolved_status(self, status_name: str) -> bool:
        """Проверить, является ли статус конечным/закрытым"""
        if not status_name:
            return False
            
        # Список статусов, которые считаются конечными/закрытыми
        resolved_statuses = [
            'closed', 'закрыт', 'закрыто', 'done', 'выполнено', 'resolved',
            'решена', 'готово', 'готов', 'отклонено', 'rejected', 'cancelled',
            'отменено', 'отменен', 'решен', 'завершено', 'завершен','Исправлен','Ответ получен','Доступ выдан'
        ]
        
        status_lower = status_name.lower().strip()
        return any(resolved_status in status_lower for resolved_status in resolved_statuses)
    
    def search_mentions_batch(self, username: str, last_check_time: str = None, 
                             batch_size: int = 10, exclude_resolved: bool = True) -> List[Dict]:
        """Поиск упоминаний с батчингом для уменьшения нагрузки"""
        try:
            # Формируем JQL для поиска упоминаний
            jql = f'text ~ "@{username}"'
            
            if last_check_time:
                try:
                    # Преобразуем дату в формат, который понимает Jira
                    # Пример: "2026-01-20T15:15:18.858818" -> "2026-01-20 15:15"
                    # Удаляем Z и заменяем T на пробел, если есть
                    clean_time = last_check_time.replace('Z', '+00:00').replace('T', ' ')
                    
                    # Пробуем разные форматы
                    formats_to_try = [
                        "%Y-%m-%d %H:%M:%S.%f",
                        "%Y-%m-%d %H:%M:%S",
                        "%Y-%m-%d %H:%M",
                        "%Y-%m-%d"
                    ]
                    
                    parsed_dt = None
                    for fmt in formats_to_try:
                        try:
                            parsed_dt = datetime.strptime(clean_time.split('+')[0].strip(), fmt)
                            break
                        except ValueError:
                            continue
                    
                    if parsed_dt:
                        # Формат для Jira: "гггг-ММ-дд ЧЧ:мм"
                        jira_time_format = parsed_dt.strftime("%Y-%m-%d %H:%M")
                        jql += f' AND updated >= "{jira_time_format}"'
                        logger.info(f"📅 Using Jira time format: {jira_time_format} (from {last_check_time})")
                    else:
                        logger.warning(f"⚠️ Could not parse time: {last_check_time}, skipping time filter")
                        
                except Exception as time_error:
                    logger.error(f"❌ Error parsing time {last_check_time}: {time_error}")
                    # Если ошибка, не добавляем временной фильтр
                    pass
            
            # Исключаем задачи в конечных статусах, если нужно
            if exclude_resolved:
                jql += f' AND status not in (Closed, Resolved, Done, "Завершено", "Закрыто", "Решено","Исправлен","Ответ получен","Доступ выдан")'
            
            logger.info(f"🔍 Searching mentions for @{username} with batch size {batch_size}")
            logger.info(f"📝 JQL: {jql}")
            
            all_issues = []
            start_at = 0
            total_issues = 0
            
            while True:
                params = {
                    "jql": jql,
                    "maxResults": batch_size,
                    "startAt": start_at,
                    "fields": "id,key,summary,assignee,status,priority,updated,comment,reporter,creator,description"
                }
                
                response = self._make_request("/rest/api/2/search", params=params)
                
                if response.status_code != 200:
                    logger.error(f"Search mentions failed: {response.status_code} - {response.text[:200]}")
                    break
                
                data = response.json()
                issues = data.get("issues", [])
                total_issues = data.get("total", 0)
                
                # Дополнительная фильтрация на случай, если JQL не полностью отфильтровал
                if exclude_resolved:
                    filtered_issues = []
                    for issue in issues:
                        status_name = issue.get("fields", {}).get("status", {}).get("name", "")
                        if not self.is_resolved_status(status_name):
                            filtered_issues.append(issue)
                        else:
                            logger.debug(f"Filtered out resolved issue: {issue.get('key')} with status: {status_name}")
                    
                    issues = filtered_issues
                
                all_issues.extend(issues)
                
                logger.info(f"Batch {start_at//batch_size + 1}: loaded {len(issues)} active issues, total {len(all_issues)}/{total_issues}")
                
                if start_at + batch_size >= total_issues or len(issues) == 0:
                    break
                    
                start_at += batch_size
                
                # Пауза между батчами чтобы не перегружать сервер
                time.sleep(1)
            
            logger.info(f"✅ Found {len(all_issues)} active issues mentioning @{username} (excluding resolved)")
            return all_issues
            
        except Exception as e:
            logger.error(f"Search mentions error: {e}")
            return []