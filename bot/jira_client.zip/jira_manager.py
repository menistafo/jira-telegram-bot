# jira_manager.py
import logging
import asyncio
from typing import Dict, Optional, List
from .jira_client import JiraClient

logger = logging.getLogger(__name__)

class JiraManager:
    def __init__(self):
        self.user_clients: Dict[int, JiraClient] = {}
        logger.info("✅ JiraManager initialized")
    
    def create_client(self, user_id: int, jira_user: str, jira_token: str, 
                     base_url: str = None) -> Optional[JiraClient]:
        """Создать Jira клиент для пользователя"""
        try:
            from .config import JIRA_BASE_URL
            base_url = base_url or JIRA_BASE_URL
            
            client = JiraClient(
                base_url=base_url,
                username=jira_user,
                token=jira_token
            )
            
            # Тестируем подключение
            if client.test_connection():
                self.user_clients[user_id] = client
                logger.info(f"✅ Jira client created for user {user_id}")
                return client
            else:
                logger.error(f"❌ Failed to create Jira client for user {user_id}")
                return None
                
        except Exception as e:
            logger.error(f"❌ Error creating Jira client: {e}")
            return None
    
    def get_client(self, user_id: int) -> Optional[JiraClient]:
        """Получить Jira клиент пользователя"""
        return self.user_clients.get(user_id)
    
    def remove_client(self, user_id: int):
        """Удалить Jira клиент пользователя"""
        if user_id in self.user_clients:
            del self.user_clients[user_id]
            logger.info(f"🗑️ Removed Jira client for user {user_id}")
    
    def test_user_connection(self, user_id: int, jira_user: str, 
                            jira_token: str) -> bool:
        """Протестировать подключение пользователя к Jira"""
        try:
            from .config import JIRA_BASE_URL
            
            # Создаем временный клиент для теста
            temp_client = JiraClient(
                base_url=JIRA_BASE_URL,
                username=jira_user,
                token=jira_token
            )
            
            return temp_client.test_connection()
            
        except Exception as e:
            logger.error(f"❌ Error testing user connection: {e}")
            return False

# Глобальный экземпляр менеджера
jira_manager = JiraManager()